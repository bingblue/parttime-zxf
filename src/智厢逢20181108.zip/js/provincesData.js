﻿/* 城市二级选择插件
 * default: 用户使用时传入的默认省市 province:默认省份 city:默认城市
 * 
 * 
 */
var citydatalist = [
  {
      "cities": [
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101010200", 
                      "name": "海淀"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101010300", 
                      "name": "朝阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101010400", 
                      "name": "顺义"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101010500", 
                      "name": "怀柔"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101010600", 
                      "name": "通州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101010700", 
                      "name": "昌平"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101010800", 
                      "name": "延庆"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101010900", 
                      "name": "丰台"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101011000", 
                      "name": "石景山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101011100", 
                      "name": "大兴"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101011200", 
                      "name": "房山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101011300", 
                      "name": "密云"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101011400", 
                      "name": "门头沟"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101011500", 
                      "name": "平谷"
                  }
              ], 
              "code": "101010200", 
              "name": "北京"
          }
      ], 
      "code": "101010200", 
      "name": "北京"
  }, 
  {
      "cities": [
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101020200", 
                      "name": "闵行"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101020300", 
                      "name": "宝山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101020500", 
                      "name": "嘉定"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101020600", 
                      "name": "南汇"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101020700", 
                      "name": "金山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101020800", 
                      "name": "青浦"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101020900", 
                      "name": "松江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101021000", 
                      "name": "奉贤"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101021100", 
                      "name": "崇明"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101021200", 
                      "name": "徐家汇"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101021300", 
                      "name": "浦东"
                  }
              ], 
              "code": "101020200", 
              "name": "上海"
          }
      ], 
      "code": "101020200", 
      "name": "上海"
  }, 
  {
      "cities": [
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101030200", 
                      "name": "武清"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101030300", 
                      "name": "宝坻"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101030400", 
                      "name": "东丽"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101030500", 
                      "name": "西青"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101030600", 
                      "name": "北辰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101030700", 
                      "name": "宁河"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101030800", 
                      "name": "汉沽"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101030900", 
                      "name": "静海"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101031000", 
                      "name": "津南"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101031100", 
                      "name": "塘沽"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101031200", 
                      "name": "大港"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101031400", 
                      "name": "蓟县"
                  }
              ], 
              "code": "101030200", 
              "name": "天津"
          }
      ], 
      "code": "101030200", 
      "name": "天津"
  }, 
  {
      "cities": [
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101040200", 
                      "name": "永川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101040300", 
                      "name": "合川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101040400", 
                      "name": "南川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101040500", 
                      "name": "江津"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101040600", 
                      "name": "万盛"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101040700", 
                      "name": "渝北"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101040800", 
                      "name": "北碚"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101040900", 
                      "name": "巴南"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101041000", 
                      "name": "长寿"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101041100", 
                      "name": "黔江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101041300", 
                      "name": "万州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101041400", 
                      "name": "涪陵"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101041500", 
                      "name": "开县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101041600", 
                      "name": "城口"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101041700", 
                      "name": "云阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101041800", 
                      "name": "巫溪"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101041900", 
                      "name": "奉节"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101042000", 
                      "name": "巫山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101042100", 
                      "name": "潼南"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101042200", 
                      "name": "垫江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101042300", 
                      "name": "梁平"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101042400", 
                      "name": "忠县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101042500", 
                      "name": "石柱"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101042600", 
                      "name": "大足"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101042700", 
                      "name": "荣昌"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101042800", 
                      "name": "铜梁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101042900", 
                      "name": "璧山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101043000", 
                      "name": "丰都"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101043100", 
                      "name": "武隆"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101043200", 
                      "name": "彭水"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101043300", 
                      "name": "綦江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101043400", 
                      "name": "酉阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101043600", 
                      "name": "秀山"
                  }
              ], 
              "code": "101040200", 
              "name": "重庆"
          }
      ], 
      "code": "101040200", 
      "name": "重庆"
  }, 
  {
      "cities": [
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101050101", 
                      "name": "哈尔滨"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050102", 
                      "name": "双城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050103", 
                      "name": "呼兰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050104", 
                      "name": "阿城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050105", 
                      "name": "宾县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050106", 
                      "name": "依兰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050107", 
                      "name": "巴彦"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050108", 
                      "name": "通河"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050109", 
                      "name": "方正"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050110", 
                      "name": "延寿"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050111", 
                      "name": "尚志"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050112", 
                      "name": "五常"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050113", 
                      "name": "木兰"
                  }
              ], 
              "code": "101050101", 
              "name": "哈尔滨"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101050201", 
                      "name": "齐齐哈尔"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050202", 
                      "name": "讷河"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050203", 
                      "name": "龙江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050204", 
                      "name": "甘南"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050205", 
                      "name": "富裕"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050206", 
                      "name": "依安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050207", 
                      "name": "拜泉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050208", 
                      "name": "克山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050209", 
                      "name": "克东"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050210", 
                      "name": "泰来"
                  }
              ], 
              "code": "101050201", 
              "name": "齐齐哈尔"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101050301", 
                      "name": "牡丹江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050302", 
                      "name": "海林"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050303", 
                      "name": "穆棱"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050304", 
                      "name": "林口"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050305", 
                      "name": "绥芬河"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050306", 
                      "name": "宁安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050307", 
                      "name": "东宁"
                  }
              ], 
              "code": "101050301", 
              "name": "牡丹江"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101050401", 
                      "name": "佳木斯"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050402", 
                      "name": "汤原"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050403", 
                      "name": "抚远"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050404", 
                      "name": "桦川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050405", 
                      "name": "桦南"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050406", 
                      "name": "同江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050407", 
                      "name": "富锦"
                  }
              ], 
              "code": "101050401", 
              "name": "佳木斯"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101050501", 
                      "name": "绥化"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050502", 
                      "name": "肇东"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050503", 
                      "name": "安达"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050504", 
                      "name": "海伦"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050505", 
                      "name": "明水"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050506", 
                      "name": "望奎"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050507", 
                      "name": "兰西"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050508", 
                      "name": "青冈"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050509", 
                      "name": "庆安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050510", 
                      "name": "绥棱"
                  }
              ], 
              "code": "101050501", 
              "name": "绥化"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101050601", 
                      "name": "黑河"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050602", 
                      "name": "嫩江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050603", 
                      "name": "孙吴"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050604", 
                      "name": "逊克"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050605", 
                      "name": "五大连池"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050606", 
                      "name": "北安"
                  }
              ], 
              "code": "101050601", 
              "name": "黑河"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101050701", 
                      "name": "大兴安岭"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050702", 
                      "name": "塔河"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050703", 
                      "name": "漠河"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050704", 
                      "name": "呼玛"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050705", 
                      "name": "呼中"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050706", 
                      "name": "新林"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050708", 
                      "name": "加格达奇"
                  }
              ], 
              "code": "101050701", 
              "name": "大兴安岭"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101050801", 
                      "name": "伊春"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050802", 
                      "name": "乌伊岭"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050803", 
                      "name": "五营"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050804", 
                      "name": "铁力"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050805", 
                      "name": "嘉荫"
                  }
              ], 
              "code": "101050801", 
              "name": "伊春"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101050901", 
                      "name": "大庆"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050902", 
                      "name": "林甸"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050903", 
                      "name": "肇州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050904", 
                      "name": "肇源"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101050905", 
                      "name": "杜尔伯特"
                  }
              ], 
              "code": "101050901", 
              "name": "大庆"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101051002", 
                      "name": "七台河"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101051003", 
                      "name": "勃利"
                  }
              ], 
              "code": "101051002", 
              "name": "七台河"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101051101", 
                      "name": "鸡西"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101051102", 
                      "name": "虎林"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101051103", 
                      "name": "密山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101051104", 
                      "name": "鸡东"
                  }
              ], 
              "code": "101051101", 
              "name": "鸡西"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101051201", 
                      "name": "鹤岗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101051202", 
                      "name": "绥滨"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101051203", 
                      "name": "萝北"
                  }
              ], 
              "code": "101051201", 
              "name": "鹤岗"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101051301", 
                      "name": "双鸭山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101051302", 
                      "name": "集贤"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101051303", 
                      "name": "宝清"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101051304", 
                      "name": "饶河"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101051305", 
                      "name": "友谊"
                  }
              ], 
              "code": "101051301", 
              "name": "双鸭山"
          }
      ], 
      "code": "101050101", 
      "name": "黑龙江"
  }, 
  {
      "cities": [
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101060101", 
                      "name": "长春"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060102", 
                      "name": "农安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060103", 
                      "name": "德惠"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060104", 
                      "name": "九台"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060105", 
                      "name": "榆树"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060106", 
                      "name": "双阳"
                  }
              ], 
              "code": "101060101", 
              "name": "长春"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101060201", 
                      "name": "吉林"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060202", 
                      "name": "舒兰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060203", 
                      "name": "永吉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060204", 
                      "name": "蛟河"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060205", 
                      "name": "磐石"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060206", 
                      "name": "桦甸"
                  }
              ], 
              "code": "101060201", 
              "name": "吉林"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101060301", 
                      "name": "延吉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060302", 
                      "name": "敦化"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060303", 
                      "name": "安图"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060304", 
                      "name": "汪清"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060305", 
                      "name": "和龙"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060307", 
                      "name": "龙井"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060308", 
                      "name": "珲春"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060309", 
                      "name": "图们"
                  }
              ], 
              "code": "101060301", 
              "name": "延边"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101060401", 
                      "name": "四平"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060402", 
                      "name": "双辽"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060403", 
                      "name": "梨树"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060404", 
                      "name": "公主岭"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060405", 
                      "name": "伊通"
                  }
              ], 
              "code": "101060401", 
              "name": "四平"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101060501", 
                      "name": "通化"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060502", 
                      "name": "梅河口"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060503", 
                      "name": "柳河"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060504", 
                      "name": "辉南"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060505", 
                      "name": "集安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060506", 
                      "name": "通化县"
                  }
              ], 
              "code": "101060501", 
              "name": "通化"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101060601", 
                      "name": "白城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060602", 
                      "name": "洮南"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060603", 
                      "name": "大安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060604", 
                      "name": "镇赉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060605", 
                      "name": "通榆"
                  }
              ], 
              "code": "101060601", 
              "name": "白城"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101060701", 
                      "name": "辽源"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060702", 
                      "name": "东丰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060703", 
                      "name": "东辽"
                  }
              ], 
              "code": "101060701", 
              "name": "辽源"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101060801", 
                      "name": "松原"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060802", 
                      "name": "乾安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060803", 
                      "name": "前郭"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060804", 
                      "name": "长岭"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060805", 
                      "name": "扶余"
                  }
              ], 
              "code": "101060801", 
              "name": "松原"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101060901", 
                      "name": "白山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060902", 
                      "name": "靖宇"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060903", 
                      "name": "临江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060904", 
                      "name": "东岗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060905", 
                      "name": "长白"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060906", 
                      "name": "抚松"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101060907", 
                      "name": "江源"
                  }
              ], 
              "code": "101060901", 
              "name": "白山"
          }
      ], 
      "code": "101060101", 
      "name": "吉林"
  }, 
  {
      "cities": [
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101070101", 
                      "name": "沈阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101070103", 
                      "name": "辽中"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101070104", 
                      "name": "康平"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101070105", 
                      "name": "法库"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101070106", 
                      "name": "新民"
                  }
              ], 
              "code": "101070101", 
              "name": "沈阳"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101070201", 
                      "name": "大连"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101070202", 
                      "name": "瓦房店"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101070203", 
                      "name": "金州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101070204", 
                      "name": "普兰店"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101070205", 
                      "name": "旅顺"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101070206", 
                      "name": "长海"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101070207", 
                      "name": "庄河"
                  }
              ], 
              "code": "101070201", 
              "name": "大连"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101070301", 
                      "name": "鞍山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101070302", 
                      "name": "台安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101070303", 
                      "name": "岫岩"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101070304", 
                      "name": "海城"
                  }
              ], 
              "code": "101070301", 
              "name": "鞍山"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101070401", 
                      "name": "抚顺"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101070402", 
                      "name": "新宾"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101070403", 
                      "name": "清原"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101070404", 
                      "name": "章党"
                  }
              ], 
              "code": "101070401", 
              "name": "抚顺"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101070501", 
                      "name": "本溪"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101070502", 
                      "name": "本溪县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101070504", 
                      "name": "桓仁"
                  }
              ], 
              "code": "101070501", 
              "name": "本溪"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101070601", 
                      "name": "丹东"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101070602", 
                      "name": "凤城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101070603", 
                      "name": "宽甸"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101070604", 
                      "name": "东港"
                  }
              ], 
              "code": "101070601", 
              "name": "丹东"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101070701", 
                      "name": "锦州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101070702", 
                      "name": "凌海"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101070704", 
                      "name": "义县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101070705", 
                      "name": "黑山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101070706", 
                      "name": "北镇"
                  }
              ], 
              "code": "101070701", 
              "name": "锦州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101070801", 
                      "name": "营口"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101070802", 
                      "name": "大石桥"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101070803", 
                      "name": "盖州"
                  }
              ], 
              "code": "101070801", 
              "name": "营口"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101070901", 
                      "name": "阜新"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101070902", 
                      "name": "彰武"
                  }
              ], 
              "code": "101070901", 
              "name": "阜新"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101071001", 
                      "name": "辽阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101071002", 
                      "name": "辽阳县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101071003", 
                      "name": "灯塔"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101071004", 
                      "name": "弓长岭"
                  }
              ], 
              "code": "101071001", 
              "name": "辽阳"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101071101", 
                      "name": "铁岭"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101071102", 
                      "name": "开原"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101071103", 
                      "name": "昌图"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101071104", 
                      "name": "西丰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101071105", 
                      "name": "铁法"
                  }
              ], 
              "code": "101071101", 
              "name": "铁岭"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101071201", 
                      "name": "朝阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101071203", 
                      "name": "凌源"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101071204", 
                      "name": "喀左"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101071205", 
                      "name": "北票"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101071207", 
                      "name": "建平县"
                  }
              ], 
              "code": "101071201", 
              "name": "朝阳"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101071301", 
                      "name": "盘锦"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101071302", 
                      "name": "大洼"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101071303", 
                      "name": "盘山"
                  }
              ], 
              "code": "101071301", 
              "name": "盘锦"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101071401", 
                      "name": "葫芦岛"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101071402", 
                      "name": "建昌"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101071403", 
                      "name": "绥中"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101071404", 
                      "name": "兴城"
                  }
              ], 
              "code": "101071401", 
              "name": "葫芦岛"
          }
      ], 
      "code": "101070101", 
      "name": "辽宁"
  }, 
  {
      "cities": [
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101080101", 
                      "name": "呼和浩特"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080102", 
                      "name": "土左旗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080103", 
                      "name": "托县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080104", 
                      "name": "和林"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080105", 
                      "name": "清水河"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080106", 
                      "name": "呼市郊区"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080107", 
                      "name": "武川"
                  }
              ], 
              "code": "101080101", 
              "name": "呼和浩特"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101080201", 
                      "name": "包头"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080202", 
                      "name": "白云鄂博"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080203", 
                      "name": "满都拉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080204", 
                      "name": "土右旗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080205", 
                      "name": "固阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080206", 
                      "name": "达茂旗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080207", 
                      "name": "希拉穆仁"
                  }
              ], 
              "code": "101080201", 
              "name": "包头"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101080301", 
                      "name": "乌海"
                  }
              ], 
              "code": "101080301", 
              "name": "乌海"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101080401", 
                      "name": "集宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080402", 
                      "name": "卓资"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080403", 
                      "name": "化德"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080404", 
                      "name": "商都"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080406", 
                      "name": "兴和"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080407", 
                      "name": "凉城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080408", 
                      "name": "察右前旗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080409", 
                      "name": "察右中旗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080410", 
                      "name": "察右后旗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080411", 
                      "name": "四子王旗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080412", 
                      "name": "丰镇"
                  }
              ], 
              "code": "101080401", 
              "name": "乌兰察布"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101080501", 
                      "name": "通辽"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080502", 
                      "name": "舍伯吐"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080503", 
                      "name": "科左中旗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080504", 
                      "name": "科左后旗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080505", 
                      "name": "青龙山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080506", 
                      "name": "开鲁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080507", 
                      "name": "库伦"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080508", 
                      "name": "奈曼"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080509", 
                      "name": "扎鲁特"
                  }
              ], 
              "code": "101080501", 
              "name": "通辽"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101080510", 
                      "name": "高力板"
                  }
              ], 
              "code": "101080510", 
              "name": "兴安盟"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101080511", 
                      "name": "巴雅尔吐胡硕"
                  }
              ], 
              "code": "101080511", 
              "name": "通辽"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101080601", 
                      "name": "赤峰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080603", 
                      "name": "阿鲁旗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080604", 
                      "name": "浩尔吐"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080605", 
                      "name": "巴林左旗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080606", 
                      "name": "巴林右旗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080607", 
                      "name": "林西"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080608", 
                      "name": "克什克腾"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080609", 
                      "name": "翁牛特"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080610", 
                      "name": "岗子"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080611", 
                      "name": "喀喇沁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080612", 
                      "name": "八里罕"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080613", 
                      "name": "宁城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080614", 
                      "name": "敖汉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080615", 
                      "name": "宝国吐"
                  }
              ], 
              "code": "101080601", 
              "name": "赤峰"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101080701", 
                      "name": "鄂尔多斯"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080703", 
                      "name": "达拉特"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080704", 
                      "name": "准格尔"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080705", 
                      "name": "鄂前旗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080706", 
                      "name": "河南"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080707", 
                      "name": "伊克乌素"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080708", 
                      "name": "鄂托克"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080709", 
                      "name": "杭锦旗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080710", 
                      "name": "乌审旗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080711", 
                      "name": "伊金霍洛"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080712", 
                      "name": "乌审召"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080713", 
                      "name": "东胜"
                  }
              ], 
              "code": "101080701", 
              "name": "鄂尔多斯"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101080801", 
                      "name": "临河"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080802", 
                      "name": "五原"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080803", 
                      "name": "磴口"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080804", 
                      "name": "乌前旗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080805", 
                      "name": "大佘太"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080806", 
                      "name": "乌中旗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080807", 
                      "name": "乌后旗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080808", 
                      "name": "海力素"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080809", 
                      "name": "那仁宝力格"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080810", 
                      "name": "杭锦后旗"
                  }
              ], 
              "code": "101080801", 
              "name": "巴彦淖尔"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101080901", 
                      "name": "锡林浩特"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080903", 
                      "name": "二连浩特"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080904", 
                      "name": "阿巴嘎"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080906", 
                      "name": "苏左旗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080907", 
                      "name": "苏右旗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080908", 
                      "name": "朱日和"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080909", 
                      "name": "东乌旗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080910", 
                      "name": "西乌旗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080911", 
                      "name": "太仆寺"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080912", 
                      "name": "镶黄旗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080913", 
                      "name": "正镶白旗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080914", 
                      "name": "正兰旗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080915", 
                      "name": "多伦"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080916", 
                      "name": "博克图"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101080917", 
                      "name": "乌拉盖"
                  }
              ], 
              "code": "101080901", 
              "name": "锡林郭勒"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101081000", 
                      "name": "呼伦贝尔"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101081001", 
                      "name": "海拉尔"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101081002", 
                      "name": "小二沟"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101081003", 
                      "name": "阿荣旗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101081004", 
                      "name": "莫力达瓦"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101081005", 
                      "name": "鄂伦春旗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101081006", 
                      "name": "鄂温克旗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101081007", 
                      "name": "陈旗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101081008", 
                      "name": "新左旗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101081009", 
                      "name": "新右旗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101081010", 
                      "name": "满洲里"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101081011", 
                      "name": "牙克石"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101081012", 
                      "name": "扎兰屯"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101081014", 
                      "name": "额尔古纳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101081015", 
                      "name": "根河"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101081016", 
                      "name": "图里河"
                  }
              ], 
              "code": "101081000", 
              "name": "呼伦贝尔"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101081101", 
                      "name": "乌兰浩特"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101081102", 
                      "name": "阿尔山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101081103", 
                      "name": "科右中旗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101081104", 
                      "name": "胡尔勒"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101081105", 
                      "name": "扎赉特"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101081106", 
                      "name": "索伦"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101081107", 
                      "name": "突泉"
                  }
              ], 
              "code": "101081101", 
              "name": "兴安盟"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101081108", 
                      "name": "霍林郭勒"
                  }
              ], 
              "code": "101081108", 
              "name": "通辽"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101081109", 
                      "name": "科右前旗"
                  }
              ], 
              "code": "101081109", 
              "name": "兴安盟"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101081201", 
                      "name": "阿左旗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101081202", 
                      "name": "阿右旗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101081203", 
                      "name": "额济纳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101081204", 
                      "name": "拐子湖"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101081205", 
                      "name": "吉兰太"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101081206", 
                      "name": "锡林高勒"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101081207", 
                      "name": "头道湖"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101081208", 
                      "name": "中泉子"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101081209", 
                      "name": "诺尔公"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101081210", 
                      "name": "雅布赖"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101081211", 
                      "name": "乌斯泰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101081212", 
                      "name": "孪井滩"
                  }
              ], 
              "code": "101081201", 
              "name": "阿拉善盟"
          }
      ], 
      "code": "101080101", 
      "name": "内蒙古"
  }, 
  {
      "cities": [
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101090101", 
                      "name": "石家庄"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090102", 
                      "name": "井陉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090103", 
                      "name": "正定"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090104", 
                      "name": "栾城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090105", 
                      "name": "行唐"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090106", 
                      "name": "灵寿"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090107", 
                      "name": "高邑"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090108", 
                      "name": "深泽"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090109", 
                      "name": "赞皇"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090110", 
                      "name": "无极"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090111", 
                      "name": "平山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090112", 
                      "name": "元氏"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090113", 
                      "name": "赵县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090114", 
                      "name": "辛集"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090115", 
                      "name": "藁城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090116", 
                      "name": "晋州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090117", 
                      "name": "新乐"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090118", 
                      "name": "鹿泉"
                  }
              ], 
              "code": "101090101", 
              "name": "石家庄"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101090201", 
                      "name": "保定"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090202", 
                      "name": "满城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090203", 
                      "name": "阜平"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090204", 
                      "name": "徐水"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090205", 
                      "name": "唐县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090206", 
                      "name": "高阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090207", 
                      "name": "容城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090209", 
                      "name": "涞源"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090210", 
                      "name": "望都"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090211", 
                      "name": "安新"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090212", 
                      "name": "易县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090214", 
                      "name": "曲阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090215", 
                      "name": "蠡县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090216", 
                      "name": "顺平"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090217", 
                      "name": "雄县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090218", 
                      "name": "涿州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090219", 
                      "name": "定州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090220", 
                      "name": "安国"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090221", 
                      "name": "高碑店"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090222", 
                      "name": "涞水"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090223", 
                      "name": "定兴"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090224", 
                      "name": "清苑"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090225", 
                      "name": "博野"
                  }
              ], 
              "code": "101090201", 
              "name": "保定"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101090301", 
                      "name": "张家口"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090302", 
                      "name": "宣化"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090303", 
                      "name": "张北"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090304", 
                      "name": "康保"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090305", 
                      "name": "沽源"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090306", 
                      "name": "尚义"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090307", 
                      "name": "蔚县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090308", 
                      "name": "阳原"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090309", 
                      "name": "怀安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090310", 
                      "name": "万全"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090311", 
                      "name": "怀来"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090312", 
                      "name": "涿鹿"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090313", 
                      "name": "赤城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090314", 
                      "name": "崇礼"
                  }
              ], 
              "code": "101090301", 
              "name": "张家口"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101090402", 
                      "name": "承德"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090403", 
                      "name": "承德县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090404", 
                      "name": "兴隆"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090405", 
                      "name": "平泉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090406", 
                      "name": "滦平"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090407", 
                      "name": "隆化"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090408", 
                      "name": "丰宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090409", 
                      "name": "宽城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090410", 
                      "name": "围场"
                  }
              ], 
              "code": "101090402", 
              "name": "承德"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101090501", 
                      "name": "唐山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090502", 
                      "name": "丰南"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090503", 
                      "name": "丰润"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090504", 
                      "name": "滦县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090505", 
                      "name": "滦南"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090506", 
                      "name": "乐亭"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090507", 
                      "name": "迁西"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090508", 
                      "name": "玉田"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090509", 
                      "name": "唐海"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090510", 
                      "name": "遵化"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090511", 
                      "name": "迁安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090512", 
                      "name": "曹妃甸"
                  }
              ], 
              "code": "101090501", 
              "name": "唐山"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101090601", 
                      "name": "廊坊"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090602", 
                      "name": "固安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090603", 
                      "name": "永清"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090604", 
                      "name": "香河"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090605", 
                      "name": "大城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090606", 
                      "name": "文安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090607", 
                      "name": "大厂"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090608", 
                      "name": "霸州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090609", 
                      "name": "三河"
                  }
              ], 
              "code": "101090601", 
              "name": "廊坊"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101090701", 
                      "name": "沧州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090702", 
                      "name": "青县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090703", 
                      "name": "东光"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090704", 
                      "name": "海兴"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090705", 
                      "name": "盐山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090706", 
                      "name": "肃宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090707", 
                      "name": "南皮"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090708", 
                      "name": "吴桥"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090709", 
                      "name": "献县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090710", 
                      "name": "孟村"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090711", 
                      "name": "泊头"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090712", 
                      "name": "任丘"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090713", 
                      "name": "黄骅"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090714", 
                      "name": "河间"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090716", 
                      "name": "沧县"
                  }
              ], 
              "code": "101090701", 
              "name": "沧州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101090801", 
                      "name": "衡水"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090802", 
                      "name": "枣强"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090803", 
                      "name": "武邑"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090804", 
                      "name": "武强"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090805", 
                      "name": "饶阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090806", 
                      "name": "安平"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090807", 
                      "name": "故城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090808", 
                      "name": "景县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090809", 
                      "name": "阜城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090810", 
                      "name": "冀州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090811", 
                      "name": "深州"
                  }
              ], 
              "code": "101090801", 
              "name": "衡水"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101090901", 
                      "name": "邢台"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090902", 
                      "name": "临城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090904", 
                      "name": "内丘"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090905", 
                      "name": "柏乡"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090906", 
                      "name": "隆尧"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090907", 
                      "name": "南和"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090908", 
                      "name": "宁晋"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090909", 
                      "name": "巨鹿"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090910", 
                      "name": "新河"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090911", 
                      "name": "广宗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090912", 
                      "name": "平乡"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090913", 
                      "name": "威县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090914", 
                      "name": "清河"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090915", 
                      "name": "临西"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090916", 
                      "name": "南宫"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090917", 
                      "name": "沙河"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101090918", 
                      "name": "任县"
                  }
              ], 
              "code": "101090901", 
              "name": "邢台"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101091001", 
                      "name": "邯郸"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101091002", 
                      "name": "峰峰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101091003", 
                      "name": "临漳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101091004", 
                      "name": "成安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101091005", 
                      "name": "大名"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101091006", 
                      "name": "涉县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101091007", 
                      "name": "磁县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101091008", 
                      "name": "肥乡"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101091009", 
                      "name": "永年"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101091010", 
                      "name": "邱县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101091011", 
                      "name": "鸡泽"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101091012", 
                      "name": "广平"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101091013", 
                      "name": "馆陶"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101091014", 
                      "name": "魏县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101091015", 
                      "name": "曲周"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101091016", 
                      "name": "武安"
                  }
              ], 
              "code": "101091001", 
              "name": "邯郸"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101091101", 
                      "name": "秦皇岛"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101091102", 
                      "name": "青龙"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101091103", 
                      "name": "昌黎"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101091104", 
                      "name": "抚宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101091105", 
                      "name": "卢龙"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101091106", 
                      "name": "北戴河"
                  }
              ], 
              "code": "101091101", 
              "name": "秦皇岛"
          }
      ], 
      "code": "101090101", 
      "name": "河北"
  }, 
  {
      "cities": [
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101100101", 
                      "name": "太原"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100102", 
                      "name": "清徐"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100103", 
                      "name": "阳曲"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100104", 
                      "name": "娄烦"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100105", 
                      "name": "古交"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100106", 
                      "name": "尖草坪区"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100107", 
                      "name": "小店区"
                  }
              ], 
              "code": "101100101", 
              "name": "太原"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101100201", 
                      "name": "大同"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100202", 
                      "name": "阳高"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100203", 
                      "name": "大同县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100204", 
                      "name": "天镇"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100205", 
                      "name": "广灵"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100206", 
                      "name": "灵丘"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100207", 
                      "name": "浑源"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100208", 
                      "name": "左云"
                  }
              ], 
              "code": "101100201", 
              "name": "大同"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101100301", 
                      "name": "阳泉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100302", 
                      "name": "盂县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100303", 
                      "name": "平定"
                  }
              ], 
              "code": "101100301", 
              "name": "阳泉"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101100401", 
                      "name": "晋中"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100402", 
                      "name": "榆次"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100403", 
                      "name": "榆社"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100404", 
                      "name": "左权"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100405", 
                      "name": "和顺"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100406", 
                      "name": "昔阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100407", 
                      "name": "寿阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100408", 
                      "name": "太谷"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100409", 
                      "name": "祁县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100410", 
                      "name": "平遥"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100411", 
                      "name": "灵石"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100412", 
                      "name": "介休"
                  }
              ], 
              "code": "101100401", 
              "name": "晋中"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101100501", 
                      "name": "长治"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100502", 
                      "name": "黎城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100503", 
                      "name": "屯留"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100504", 
                      "name": "潞城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100505", 
                      "name": "襄垣"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100506", 
                      "name": "平顺"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100507", 
                      "name": "武乡"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100508", 
                      "name": "沁县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100509", 
                      "name": "长子"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100510", 
                      "name": "沁源"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100511", 
                      "name": "壶关"
                  }
              ], 
              "code": "101100501", 
              "name": "长治"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101100601", 
                      "name": "晋城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100602", 
                      "name": "沁水"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100603", 
                      "name": "阳城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100604", 
                      "name": "陵川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100605", 
                      "name": "高平"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100606", 
                      "name": "泽州"
                  }
              ], 
              "code": "101100601", 
              "name": "晋城"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101100701", 
                      "name": "临汾"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100702", 
                      "name": "曲沃"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100703", 
                      "name": "永和"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100704", 
                      "name": "隰县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100705", 
                      "name": "大宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100706", 
                      "name": "吉县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100707", 
                      "name": "襄汾"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100708", 
                      "name": "蒲县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100709", 
                      "name": "汾西"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100710", 
                      "name": "洪洞"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100711", 
                      "name": "霍州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100712", 
                      "name": "乡宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100713", 
                      "name": "翼城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100714", 
                      "name": "侯马"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100715", 
                      "name": "浮山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100716", 
                      "name": "安泽"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100717", 
                      "name": "古县"
                  }
              ], 
              "code": "101100701", 
              "name": "临汾"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101100801", 
                      "name": "运城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100802", 
                      "name": "临猗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100803", 
                      "name": "稷山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100804", 
                      "name": "万荣"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100805", 
                      "name": "河津"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100806", 
                      "name": "新绛"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100807", 
                      "name": "绛县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100808", 
                      "name": "闻喜"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100809", 
                      "name": "垣曲"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100810", 
                      "name": "永济"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100811", 
                      "name": "芮城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100812", 
                      "name": "夏县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100813", 
                      "name": "平陆"
                  }
              ], 
              "code": "101100801", 
              "name": "运城"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101100901", 
                      "name": "朔州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100902", 
                      "name": "平鲁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100903", 
                      "name": "山阴"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100904", 
                      "name": "右玉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100905", 
                      "name": "应县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101100906", 
                      "name": "怀仁"
                  }
              ], 
              "code": "101100901", 
              "name": "朔州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101101001", 
                      "name": "忻州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101101002", 
                      "name": "定襄"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101101003", 
                      "name": "五台县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101101004", 
                      "name": "河曲"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101101005", 
                      "name": "偏关"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101101006", 
                      "name": "神池"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101101007", 
                      "name": "宁武"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101101008", 
                      "name": "代县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101101009", 
                      "name": "繁峙"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101101010", 
                      "name": "五台山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101101011", 
                      "name": "保德"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101101012", 
                      "name": "静乐"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101101013", 
                      "name": "岢岚"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101101014", 
                      "name": "五寨"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101101015", 
                      "name": "原平"
                  }
              ], 
              "code": "101101001", 
              "name": "忻州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101101100", 
                      "name": "吕梁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101101101", 
                      "name": "离石"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101101102", 
                      "name": "临县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101101103", 
                      "name": "兴县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101101104", 
                      "name": "岚县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101101105", 
                      "name": "柳林"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101101106", 
                      "name": "石楼"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101101107", 
                      "name": "方山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101101108", 
                      "name": "交口"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101101109", 
                      "name": "中阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101101110", 
                      "name": "孝义"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101101111", 
                      "name": "汾阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101101112", 
                      "name": "文水"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101101113", 
                      "name": "交城"
                  }
              ], 
              "code": "101101100", 
              "name": "吕梁"
          }
      ], 
      "code": "101100101", 
      "name": "山西"
  }, 
  {
      "cities": [
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101110101", 
                      "name": "西安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110102", 
                      "name": "长安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110103", 
                      "name": "临潼"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110104", 
                      "name": "蓝田"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110105", 
                      "name": "周至"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110106", 
                      "name": "户县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110107", 
                      "name": "高陵"
                  }
              ], 
              "code": "101110101", 
              "name": "西安"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101110200", 
                      "name": "咸阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110201", 
                      "name": "三原"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110202", 
                      "name": "礼泉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110203", 
                      "name": "永寿"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110204", 
                      "name": "淳化"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110205", 
                      "name": "泾阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110206", 
                      "name": "武功"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110207", 
                      "name": "乾县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110208", 
                      "name": "彬县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110209", 
                      "name": "长武"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110210", 
                      "name": "旬邑"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110211", 
                      "name": "兴平"
                  }
              ], 
              "code": "101110200", 
              "name": "咸阳"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101110300", 
                      "name": "延安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110301", 
                      "name": "延长"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110302", 
                      "name": "延川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110303", 
                      "name": "子长"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110304", 
                      "name": "宜川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110305", 
                      "name": "富县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110306", 
                      "name": "志丹"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110307", 
                      "name": "安塞"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110308", 
                      "name": "甘泉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110309", 
                      "name": "洛川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110310", 
                      "name": "黄陵"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110311", 
                      "name": "黄龙"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110312", 
                      "name": "吴起"
                  }
              ], 
              "code": "101110300", 
              "name": "延安"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101110401", 
                      "name": "榆林"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110402", 
                      "name": "府谷"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110403", 
                      "name": "神木"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110404", 
                      "name": "佳县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110405", 
                      "name": "定边"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110406", 
                      "name": "靖边"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110407", 
                      "name": "横山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110408", 
                      "name": "米脂"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110409", 
                      "name": "子洲"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110410", 
                      "name": "绥德"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110411", 
                      "name": "吴堡"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110412", 
                      "name": "清涧"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110413", 
                      "name": "榆阳"
                  }
              ], 
              "code": "101110401", 
              "name": "榆林"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101110501", 
                      "name": "渭南"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110502", 
                      "name": "华县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110503", 
                      "name": "潼关"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110504", 
                      "name": "大荔"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110505", 
                      "name": "白水"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110506", 
                      "name": "富平"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110507", 
                      "name": "蒲城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110508", 
                      "name": "澄城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110509", 
                      "name": "合阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110510", 
                      "name": "韩城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110511", 
                      "name": "华阴"
                  }
              ], 
              "code": "101110501", 
              "name": "渭南"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101110601", 
                      "name": "商洛"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110602", 
                      "name": "洛南"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110603", 
                      "name": "柞水"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110604", 
                      "name": "商州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110605", 
                      "name": "镇安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110606", 
                      "name": "丹凤"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110607", 
                      "name": "商南"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110608", 
                      "name": "山阳"
                  }
              ], 
              "code": "101110601", 
              "name": "商洛"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101110701", 
                      "name": "安康"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110702", 
                      "name": "紫阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110703", 
                      "name": "石泉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110704", 
                      "name": "汉阴"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110705", 
                      "name": "旬阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110706", 
                      "name": "岚皋"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110707", 
                      "name": "平利"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110708", 
                      "name": "白河"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110709", 
                      "name": "镇坪"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110710", 
                      "name": "宁陕"
                  }
              ], 
              "code": "101110701", 
              "name": "安康"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101110801", 
                      "name": "汉中"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110802", 
                      "name": "略阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110803", 
                      "name": "勉县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110804", 
                      "name": "留坝"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110805", 
                      "name": "洋县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110806", 
                      "name": "城固"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110807", 
                      "name": "西乡"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110808", 
                      "name": "佛坪"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110809", 
                      "name": "宁强"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110810", 
                      "name": "南郑"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110811", 
                      "name": "镇巴"
                  }
              ], 
              "code": "101110801", 
              "name": "汉中"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101110901", 
                      "name": "宝鸡"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110903", 
                      "name": "千阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110904", 
                      "name": "麟游"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110905", 
                      "name": "岐山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110906", 
                      "name": "凤翔"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110907", 
                      "name": "扶风"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110908", 
                      "name": "眉县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110909", 
                      "name": "太白"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110910", 
                      "name": "凤县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110911", 
                      "name": "陇县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101110912", 
                      "name": "陈仓"
                  }
              ], 
              "code": "101110901", 
              "name": "宝鸡"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101111001", 
                      "name": "铜川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101111002", 
                      "name": "耀县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101111003", 
                      "name": "宜君"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101111004", 
                      "name": "耀州"
                  }
              ], 
              "code": "101111001", 
              "name": "铜川"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101111101", 
                      "name": "杨凌"
                  }
              ], 
              "code": "101111101", 
              "name": "杨凌"
          }
      ], 
      "code": "101110101", 
      "name": "陕西"
  }, 
  {
      "cities": [
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101120101", 
                      "name": "济南"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120102", 
                      "name": "长清"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120103", 
                      "name": "商河"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120104", 
                      "name": "章丘"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120105", 
                      "name": "平阴"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120106", 
                      "name": "济阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120107", 
                      "name": "天桥"
                  }
              ], 
              "code": "101120101", 
              "name": "济南"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101120201", 
                      "name": "青岛"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120202", 
                      "name": "崂山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120204", 
                      "name": "即墨"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120205", 
                      "name": "胶州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120206", 
                      "name": "胶南"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120207", 
                      "name": "莱西"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120208", 
                      "name": "平度"
                  }
              ], 
              "code": "101120201", 
              "name": "青岛"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101120301", 
                      "name": "淄博"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120302", 
                      "name": "淄川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120303", 
                      "name": "博山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120304", 
                      "name": "高青"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120305", 
                      "name": "周村"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120306", 
                      "name": "沂源"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120307", 
                      "name": "桓台"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120308", 
                      "name": "临淄"
                  }
              ], 
              "code": "101120301", 
              "name": "淄博"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101120401", 
                      "name": "德州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120402", 
                      "name": "武城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120403", 
                      "name": "临邑"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120404", 
                      "name": "陵县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120405", 
                      "name": "齐河"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120406", 
                      "name": "乐陵"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120407", 
                      "name": "庆云"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120408", 
                      "name": "平原"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120409", 
                      "name": "宁津"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120410", 
                      "name": "夏津"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120411", 
                      "name": "禹城"
                  }
              ], 
              "code": "101120401", 
              "name": "德州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101120501", 
                      "name": "烟台"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120502", 
                      "name": "莱州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120503", 
                      "name": "长岛"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120504", 
                      "name": "蓬莱"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120505", 
                      "name": "龙口"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120506", 
                      "name": "招远"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120507", 
                      "name": "栖霞"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120508", 
                      "name": "福山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120509", 
                      "name": "牟平"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120510", 
                      "name": "莱阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120511", 
                      "name": "海阳"
                  }
              ], 
              "code": "101120501", 
              "name": "烟台"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101120601", 
                      "name": "潍坊"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120602", 
                      "name": "青州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120603", 
                      "name": "寿光"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120604", 
                      "name": "临朐"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120605", 
                      "name": "昌乐"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120606", 
                      "name": "昌邑"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120607", 
                      "name": "安丘"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120608", 
                      "name": "高密"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120609", 
                      "name": "诸城"
                  }
              ], 
              "code": "101120601", 
              "name": "潍坊"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101120701", 
                      "name": "济宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120702", 
                      "name": "嘉祥"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120703", 
                      "name": "微山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120704", 
                      "name": "鱼台"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120705", 
                      "name": "兖州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120706", 
                      "name": "金乡"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120707", 
                      "name": "汶上"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120708", 
                      "name": "泗水"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120709", 
                      "name": "梁山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120710", 
                      "name": "曲阜"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120711", 
                      "name": "邹城"
                  }
              ], 
              "code": "101120701", 
              "name": "济宁"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101120801", 
                      "name": "泰安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120802", 
                      "name": "新泰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120804", 
                      "name": "肥城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120805", 
                      "name": "东平"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120806", 
                      "name": "宁阳"
                  }
              ], 
              "code": "101120801", 
              "name": "泰安"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101120901", 
                      "name": "临沂"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120902", 
                      "name": "莒南"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120903", 
                      "name": "沂南"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120904", 
                      "name": "苍山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120905", 
                      "name": "临沭"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120906", 
                      "name": "郯城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120907", 
                      "name": "蒙阴"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120908", 
                      "name": "平邑"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120909", 
                      "name": "费县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101120910", 
                      "name": "沂水"
                  }
              ], 
              "code": "101120901", 
              "name": "临沂"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101121001", 
                      "name": "菏泽"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101121002", 
                      "name": "鄄城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101121003", 
                      "name": "郓城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101121004", 
                      "name": "东明"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101121005", 
                      "name": "定陶"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101121006", 
                      "name": "巨野"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101121007", 
                      "name": "曹县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101121008", 
                      "name": "成武"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101121009", 
                      "name": "单县"
                  }
              ], 
              "code": "101121001", 
              "name": "菏泽"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101121101", 
                      "name": "滨州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101121102", 
                      "name": "博兴"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101121103", 
                      "name": "无棣"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101121104", 
                      "name": "阳信"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101121105", 
                      "name": "惠民"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101121106", 
                      "name": "沾化"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101121107", 
                      "name": "邹平"
                  }
              ], 
              "code": "101121101", 
              "name": "滨州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101121201", 
                      "name": "东营"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101121202", 
                      "name": "河口"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101121203", 
                      "name": "垦利"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101121204", 
                      "name": "利津"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101121205", 
                      "name": "广饶"
                  }
              ], 
              "code": "101121201", 
              "name": "东营"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101121301", 
                      "name": "威海"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101121302", 
                      "name": "文登"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101121303", 
                      "name": "荣成"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101121304", 
                      "name": "乳山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101121305", 
                      "name": "成山头"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101121306", 
                      "name": "石岛"
                  }
              ], 
              "code": "101121301", 
              "name": "威海"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101121401", 
                      "name": "枣庄"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101121402", 
                      "name": "薛城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101121403", 
                      "name": "峄城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101121404", 
                      "name": "台儿庄"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101121405", 
                      "name": "滕州"
                  }
              ], 
              "code": "101121401", 
              "name": "枣庄"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101121501", 
                      "name": "日照"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101121502", 
                      "name": "五莲"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101121503", 
                      "name": "莒县"
                  }
              ], 
              "code": "101121501", 
              "name": "日照"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101121601", 
                      "name": "莱芜"
                  }
              ], 
              "code": "101121601", 
              "name": "莱芜"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101121701", 
                      "name": "聊城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101121702", 
                      "name": "冠县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101121703", 
                      "name": "阳谷"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101121704", 
                      "name": "高唐"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101121705", 
                      "name": "茌平"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101121706", 
                      "name": "东阿"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101121707", 
                      "name": "临清"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101121709", 
                      "name": "莘县"
                  }
              ], 
              "code": "101121701", 
              "name": "聊城"
          }
      ], 
      "code": "101120101", 
      "name": "山东"
  }, 
  {
      "cities": [
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101130101", 
                      "name": "乌鲁木齐"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130103", 
                      "name": "小渠子"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130104", 
                      "name": "巴仑台"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130105", 
                      "name": "达坂城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130108", 
                      "name": "乌鲁木齐牧试站"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130109", 
                      "name": "天池"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130110", 
                      "name": "白杨沟"
                  }
              ], 
              "code": "101130101", 
              "name": "乌鲁木齐"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101130201", 
                      "name": "克拉玛依"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130202", 
                      "name": "乌尔禾"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130203", 
                      "name": "白碱滩"
                  }
              ], 
              "code": "101130201", 
              "name": "克拉玛依"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101130301", 
                      "name": "石河子"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130302", 
                      "name": "炮台"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130303", 
                      "name": "莫索湾"
                  }
              ], 
              "code": "101130301", 
              "name": "石河子"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101130401", 
                      "name": "昌吉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130402", 
                      "name": "呼图壁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130403", 
                      "name": "米泉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130404", 
                      "name": "阜康"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130405", 
                      "name": "吉木萨尔"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130406", 
                      "name": "奇台"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130407", 
                      "name": "玛纳斯"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130408", 
                      "name": "木垒"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130409", 
                      "name": "蔡家湖"
                  }
              ], 
              "code": "101130401", 
              "name": "昌吉"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101130501", 
                      "name": "吐鲁番"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130502", 
                      "name": "托克逊"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130503", 
                      "name": "克孜勒"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130504", 
                      "name": "鄯善"
                  }
              ], 
              "code": "101130501", 
              "name": "吐鲁番"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101130601", 
                      "name": "库尔勒"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130602", 
                      "name": "轮台"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130603", 
                      "name": "尉犁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130604", 
                      "name": "若羌"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130605", 
                      "name": "且末"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130606", 
                      "name": "和静"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130607", 
                      "name": "焉耆"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130608", 
                      "name": "和硕"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130610", 
                      "name": "巴音布鲁克"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130611", 
                      "name": "铁干里克"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130612", 
                      "name": "博湖"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130613", 
                      "name": "塔中"
                  }
              ], 
              "code": "101130601", 
              "name": "巴音郭楞"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101130701", 
                      "name": "阿拉尔"
                  }
              ], 
              "code": "101130701", 
              "name": "阿拉尔"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101130801", 
                      "name": "阿克苏"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130802", 
                      "name": "乌什"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130803", 
                      "name": "温宿"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130804", 
                      "name": "拜城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130805", 
                      "name": "新和"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130806", 
                      "name": "沙雅"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130807", 
                      "name": "库车"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130808", 
                      "name": "柯坪"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130809", 
                      "name": "阿瓦提"
                  }
              ], 
              "code": "101130801", 
              "name": "阿克苏"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101130901", 
                      "name": "喀什"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130902", 
                      "name": "英吉沙"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130903", 
                      "name": "塔什库尔干"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130904", 
                      "name": "麦盖提"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130905", 
                      "name": "莎车"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130906", 
                      "name": "叶城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130907", 
                      "name": "泽普"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130908", 
                      "name": "巴楚"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130909", 
                      "name": "岳普湖"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130910", 
                      "name": "伽师"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130911", 
                      "name": "疏附"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101130912", 
                      "name": "疏勒"
                  }
              ], 
              "code": "101130901", 
              "name": "喀什"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101131001", 
                      "name": "伊宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131002", 
                      "name": "察布查尔"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131003", 
                      "name": "尼勒克"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131004", 
                      "name": "伊宁县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131005", 
                      "name": "巩留"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131006", 
                      "name": "新源"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131007", 
                      "name": "昭苏"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131008", 
                      "name": "特克斯"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131009", 
                      "name": "霍城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131010", 
                      "name": "霍尔果斯"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131011", 
                      "name": "奎屯"
                  }
              ], 
              "code": "101131001", 
              "name": "伊犁"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101131101", 
                      "name": "塔城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131102", 
                      "name": "裕民"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131103", 
                      "name": "额敏"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131104", 
                      "name": "和布克赛尔"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131105", 
                      "name": "托里"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131106", 
                      "name": "乌苏"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131107", 
                      "name": "沙湾"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131108", 
                      "name": "和丰"
                  }
              ], 
              "code": "101131101", 
              "name": "塔城"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101131201", 
                      "name": "哈密"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131203", 
                      "name": "巴里坤"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131204", 
                      "name": "伊吾"
                  }
              ], 
              "code": "101131201", 
              "name": "哈密"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101131301", 
                      "name": "和田"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131302", 
                      "name": "皮山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131303", 
                      "name": "策勒"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131304", 
                      "name": "墨玉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131305", 
                      "name": "洛浦"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131306", 
                      "name": "民丰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131307", 
                      "name": "于田"
                  }
              ], 
              "code": "101131301", 
              "name": "和田"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101131401", 
                      "name": "阿勒泰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131402", 
                      "name": "哈巴河"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131405", 
                      "name": "吉木乃"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131406", 
                      "name": "布尔津"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131407", 
                      "name": "福海"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131408", 
                      "name": "富蕴"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131409", 
                      "name": "青河"
                  }
              ], 
              "code": "101131401", 
              "name": "阿勒泰"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101131501", 
                      "name": "阿图什"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131502", 
                      "name": "乌恰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131503", 
                      "name": "阿克陶"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131504", 
                      "name": "阿合奇"
                  }
              ], 
              "code": "101131501", 
              "name": "克州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101131601", 
                      "name": "博乐"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131602", 
                      "name": "温泉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131603", 
                      "name": "精河"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101131606", 
                      "name": "阿拉山口"
                  }
              ], 
              "code": "101131601", 
              "name": "博尔塔拉"
          }
      ], 
      "code": "101130101", 
      "name": "新疆"
  }, 
  {
      "cities": [
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101140101", 
                      "name": "拉萨"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140102", 
                      "name": "当雄"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140103", 
                      "name": "尼木"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140104", 
                      "name": "林周"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140105", 
                      "name": "堆龙德庆"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140106", 
                      "name": "曲水"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140107", 
                      "name": "达孜"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140108", 
                      "name": "墨竹工卡"
                  }
              ], 
              "code": "101140101", 
              "name": "拉萨"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101140201", 
                      "name": "日喀则"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140202", 
                      "name": "拉孜"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140203", 
                      "name": "南木林"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140204", 
                      "name": "聂拉木"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140205", 
                      "name": "定日"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140206", 
                      "name": "江孜"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140207", 
                      "name": "帕里"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140208", 
                      "name": "仲巴"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140209", 
                      "name": "萨嘎"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140210", 
                      "name": "吉隆"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140211", 
                      "name": "昂仁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140212", 
                      "name": "定结"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140213", 
                      "name": "萨迦"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140214", 
                      "name": "谢通门"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140216", 
                      "name": "岗巴"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140217", 
                      "name": "白朗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140218", 
                      "name": "亚东"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140219", 
                      "name": "康马"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140220", 
                      "name": "仁布"
                  }
              ], 
              "code": "101140201", 
              "name": "日喀则"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101140301", 
                      "name": "山南"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140302", 
                      "name": "贡嘎"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140303", 
                      "name": "札囊"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140304", 
                      "name": "加查"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140305", 
                      "name": "浪卡子"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140306", 
                      "name": "错那"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140307", 
                      "name": "隆子"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140308", 
                      "name": "泽当"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140309", 
                      "name": "乃东"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140310", 
                      "name": "桑日"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140311", 
                      "name": "洛扎"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140312", 
                      "name": "措美"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140313", 
                      "name": "琼结"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140314", 
                      "name": "曲松"
                  }
              ], 
              "code": "101140301", 
              "name": "山南"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101140401", 
                      "name": "林芝"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140402", 
                      "name": "波密"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140403", 
                      "name": "米林"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140404", 
                      "name": "察隅"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140405", 
                      "name": "工布江达"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140406", 
                      "name": "朗县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140407", 
                      "name": "墨脱"
                  }
              ], 
              "code": "101140401", 
              "name": "林芝"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101140501", 
                      "name": "昌都"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140502", 
                      "name": "丁青"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140503", 
                      "name": "边坝"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140504", 
                      "name": "洛隆"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140505", 
                      "name": "左贡"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140506", 
                      "name": "芒康"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140507", 
                      "name": "类乌齐"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140508", 
                      "name": "八宿"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140509", 
                      "name": "江达"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140510", 
                      "name": "察雅"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140511", 
                      "name": "贡觉"
                  }
              ], 
              "code": "101140501", 
              "name": "昌都"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101140601", 
                      "name": "那曲"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140602", 
                      "name": "尼玛"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140603", 
                      "name": "嘉黎"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140604", 
                      "name": "班戈"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140605", 
                      "name": "安多"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140606", 
                      "name": "索县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140607", 
                      "name": "聂荣"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140608", 
                      "name": "巴青"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140609", 
                      "name": "比如"
                  }
              ], 
              "code": "101140601", 
              "name": "那曲"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101140701", 
                      "name": "阿里"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140702", 
                      "name": "改则"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140703", 
                      "name": "申扎"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140704", 
                      "name": "狮泉河"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140705", 
                      "name": "普兰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140706", 
                      "name": "札达"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140707", 
                      "name": "噶尔"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140708", 
                      "name": "日土"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140709", 
                      "name": "革吉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101140710", 
                      "name": "措勤"
                  }
              ], 
              "code": "101140701", 
              "name": "阿里"
          }
      ], 
      "code": "101140101", 
      "name": "西藏"
  }, 
  {
      "cities": [
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101150101", 
                      "name": "西宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150102", 
                      "name": "大通"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150103", 
                      "name": "湟源"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150104", 
                      "name": "湟中"
                  }
              ], 
              "code": "101150101", 
              "name": "西宁"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101150201", 
                      "name": "海东"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150202", 
                      "name": "乐都"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150203", 
                      "name": "民和"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150204", 
                      "name": "互助"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150205", 
                      "name": "化隆"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150206", 
                      "name": "循化"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150207", 
                      "name": "冷湖"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150208", 
                      "name": "平安"
                  }
              ], 
              "code": "101150201", 
              "name": "海东"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101150301", 
                      "name": "黄南"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150302", 
                      "name": "尖扎"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150303", 
                      "name": "泽库"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150304", 
                      "name": "河南"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150305", 
                      "name": "同仁"
                  }
              ], 
              "code": "101150301", 
              "name": "黄南"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101150401", 
                      "name": "海南"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150404", 
                      "name": "贵德"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150406", 
                      "name": "兴海"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150407", 
                      "name": "贵南"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150408", 
                      "name": "同德"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150409", 
                      "name": "共和"
                  }
              ], 
              "code": "101150401", 
              "name": "海南"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101150501", 
                      "name": "果洛"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150502", 
                      "name": "班玛"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150503", 
                      "name": "甘德"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150504", 
                      "name": "达日"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150505", 
                      "name": "久治"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150506", 
                      "name": "玛多"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150507", 
                      "name": "多县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150508", 
                      "name": "玛沁"
                  }
              ], 
              "code": "101150501", 
              "name": "果洛"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101150601", 
                      "name": "玉树"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150602", 
                      "name": "称多"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150603", 
                      "name": "治多"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150604", 
                      "name": "杂多"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150605", 
                      "name": "囊谦"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150606", 
                      "name": "曲麻莱"
                  }
              ], 
              "code": "101150601", 
              "name": "玉树"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101150701", 
                      "name": "海西"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150708", 
                      "name": "天峻"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150709", 
                      "name": "乌兰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150712", 
                      "name": "茫崖"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150713", 
                      "name": "大柴旦"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150716", 
                      "name": "德令哈"
                  }
              ], 
              "code": "101150701", 
              "name": "海西"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101150801", 
                      "name": "海北"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150802", 
                      "name": "门源"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150803", 
                      "name": "祁连"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150804", 
                      "name": "海晏"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150806", 
                      "name": "刚察"
                  }
              ], 
              "code": "101150801", 
              "name": "海北"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101150901", 
                      "name": "格尔木"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101150902", 
                      "name": "都兰"
                  }
              ], 
              "code": "101150901", 
              "name": "格尔木"
          }
      ], 
      "code": "101150101", 
      "name": "青海"
  }, 
  {
      "cities": [
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101160101", 
                      "name": "兰州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160102", 
                      "name": "皋兰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160103", 
                      "name": "永登"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160104", 
                      "name": "榆中"
                  }
              ], 
              "code": "101160101", 
              "name": "兰州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101160201", 
                      "name": "定西"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160202", 
                      "name": "通渭"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160203", 
                      "name": "陇西"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160204", 
                      "name": "渭源"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160205", 
                      "name": "临洮"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160206", 
                      "name": "漳县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160207", 
                      "name": "岷县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160208", 
                      "name": "安定"
                  }
              ], 
              "code": "101160201", 
              "name": "定西"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101160301", 
                      "name": "平凉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160302", 
                      "name": "泾川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160303", 
                      "name": "灵台"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160304", 
                      "name": "崇信"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160305", 
                      "name": "华亭"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160306", 
                      "name": "庄浪"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160307", 
                      "name": "静宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160308", 
                      "name": "崆峒"
                  }
              ], 
              "code": "101160301", 
              "name": "平凉"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101160401", 
                      "name": "庆阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160402", 
                      "name": "西峰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160403", 
                      "name": "环县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160404", 
                      "name": "华池"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160405", 
                      "name": "合水"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160406", 
                      "name": "正宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160407", 
                      "name": "宁县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160408", 
                      "name": "镇原"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160409", 
                      "name": "庆城"
                  }
              ], 
              "code": "101160401", 
              "name": "庆阳"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101160501", 
                      "name": "武威"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160502", 
                      "name": "民勤"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160503", 
                      "name": "古浪"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160505", 
                      "name": "天祝"
                  }
              ], 
              "code": "101160501", 
              "name": "武威"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101160601", 
                      "name": "金昌"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160602", 
                      "name": "永昌"
                  }
              ], 
              "code": "101160601", 
              "name": "金昌"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101160701", 
                      "name": "张掖"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160702", 
                      "name": "肃南"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160703", 
                      "name": "民乐"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160704", 
                      "name": "临泽"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160705", 
                      "name": "高台"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160706", 
                      "name": "山丹"
                  }
              ], 
              "code": "101160701", 
              "name": "张掖"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101160801", 
                      "name": "酒泉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160803", 
                      "name": "金塔"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160804", 
                      "name": "阿克塞"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160805", 
                      "name": "瓜州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160806", 
                      "name": "肃北"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160807", 
                      "name": "玉门"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160808", 
                      "name": "敦煌"
                  }
              ], 
              "code": "101160801", 
              "name": "酒泉"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101160901", 
                      "name": "天水"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160903", 
                      "name": "清水"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160904", 
                      "name": "秦安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160905", 
                      "name": "甘谷"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160906", 
                      "name": "武山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160907", 
                      "name": "张家川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101160908", 
                      "name": "麦积"
                  }
              ], 
              "code": "101160901", 
              "name": "天水"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101161001", 
                      "name": "武都"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101161002", 
                      "name": "成县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101161003", 
                      "name": "文县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101161004", 
                      "name": "宕昌"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101161005", 
                      "name": "康县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101161006", 
                      "name": "西和"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101161007", 
                      "name": "礼县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101161008", 
                      "name": "徽县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101161009", 
                      "name": "两当"
                  }
              ], 
              "code": "101161001", 
              "name": "陇南"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101161101", 
                      "name": "临夏"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101161102", 
                      "name": "康乐"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101161103", 
                      "name": "永靖"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101161104", 
                      "name": "广河"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101161105", 
                      "name": "和政"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101161106", 
                      "name": "东乡"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101161107", 
                      "name": "积石山"
                  }
              ], 
              "code": "101161101", 
              "name": "临夏"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101161201", 
                      "name": "合作"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101161202", 
                      "name": "临潭"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101161203", 
                      "name": "卓尼"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101161204", 
                      "name": "舟曲"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101161205", 
                      "name": "迭部"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101161206", 
                      "name": "玛曲"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101161207", 
                      "name": "碌曲"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101161208", 
                      "name": "夏河"
                  }
              ], 
              "code": "101161201", 
              "name": "甘南"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101161301", 
                      "name": "白银"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101161302", 
                      "name": "靖远"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101161303", 
                      "name": "会宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101161304", 
                      "name": "平川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101161305", 
                      "name": "景泰"
                  }
              ], 
              "code": "101161301", 
              "name": "白银"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101161401", 
                      "name": "嘉峪关"
                  }
              ], 
              "code": "101161401", 
              "name": "嘉峪关"
          }
      ], 
      "code": "101160101", 
      "name": "甘肃"
  }, 
  {
      "cities": [
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101170101", 
                      "name": "银川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101170102", 
                      "name": "永宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101170103", 
                      "name": "灵武"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101170104", 
                      "name": "贺兰"
                  }
              ], 
              "code": "101170101", 
              "name": "银川"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101170201", 
                      "name": "石嘴山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101170202", 
                      "name": "惠农"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101170203", 
                      "name": "平罗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101170204", 
                      "name": "陶乐"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101170206", 
                      "name": "大武口"
                  }
              ], 
              "code": "101170201", 
              "name": "石嘴山"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101170301", 
                      "name": "吴忠"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101170302", 
                      "name": "同心"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101170303", 
                      "name": "盐池"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101170306", 
                      "name": "青铜峡"
                  }
              ], 
              "code": "101170301", 
              "name": "吴忠"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101170401", 
                      "name": "固原"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101170402", 
                      "name": "西吉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101170403", 
                      "name": "隆德"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101170404", 
                      "name": "泾源"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101170406", 
                      "name": "彭阳"
                  }
              ], 
              "code": "101170401", 
              "name": "固原"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101170501", 
                      "name": "中卫"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101170502", 
                      "name": "中宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101170504", 
                      "name": "海原"
                  }
              ], 
              "code": "101170501", 
              "name": "中卫"
          }
      ], 
      "code": "101170101", 
      "name": "宁夏"
  }, 
  {
      "cities": [
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101180101", 
                      "name": "郑州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180102", 
                      "name": "巩义"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180103", 
                      "name": "荥阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180104", 
                      "name": "登封"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180105", 
                      "name": "新密"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180106", 
                      "name": "新郑"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180107", 
                      "name": "中牟"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180108", 
                      "name": "上街"
                  }
              ], 
              "code": "101180101", 
              "name": "郑州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101180201", 
                      "name": "安阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180202", 
                      "name": "汤阴"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180203", 
                      "name": "滑县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180204", 
                      "name": "内黄"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180205", 
                      "name": "林州"
                  }
              ], 
              "code": "101180201", 
              "name": "安阳"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101180301", 
                      "name": "新乡"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180302", 
                      "name": "获嘉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180303", 
                      "name": "原阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180304", 
                      "name": "辉县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180305", 
                      "name": "卫辉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180306", 
                      "name": "延津"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180307", 
                      "name": "封丘"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180308", 
                      "name": "长垣"
                  }
              ], 
              "code": "101180301", 
              "name": "新乡"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101180401", 
                      "name": "许昌"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180402", 
                      "name": "鄢陵"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180403", 
                      "name": "襄城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180404", 
                      "name": "长葛"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180405", 
                      "name": "禹州"
                  }
              ], 
              "code": "101180401", 
              "name": "许昌"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101180501", 
                      "name": "平顶山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180502", 
                      "name": "郏县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180503", 
                      "name": "宝丰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180504", 
                      "name": "汝州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180505", 
                      "name": "叶县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180506", 
                      "name": "舞钢"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180507", 
                      "name": "鲁山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180508", 
                      "name": "石龙"
                  }
              ], 
              "code": "101180501", 
              "name": "平顶山"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101180601", 
                      "name": "信阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180602", 
                      "name": "息县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180603", 
                      "name": "罗山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180604", 
                      "name": "光山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180605", 
                      "name": "新县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180606", 
                      "name": "淮滨"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180607", 
                      "name": "潢川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180608", 
                      "name": "固始"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180609", 
                      "name": "商城"
                  }
              ], 
              "code": "101180601", 
              "name": "信阳"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101180701", 
                      "name": "南阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180702", 
                      "name": "南召"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180703", 
                      "name": "方城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180704", 
                      "name": "社旗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180705", 
                      "name": "西峡"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180706", 
                      "name": "内乡"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180707", 
                      "name": "镇平"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180708", 
                      "name": "淅川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180709", 
                      "name": "新野"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180710", 
                      "name": "唐河"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180711", 
                      "name": "邓州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180712", 
                      "name": "桐柏"
                  }
              ], 
              "code": "101180701", 
              "name": "南阳"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101180801", 
                      "name": "开封"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180802", 
                      "name": "杞县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180803", 
                      "name": "尉氏"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180804", 
                      "name": "通许"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180805", 
                      "name": "兰考"
                  }
              ], 
              "code": "101180801", 
              "name": "开封"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101180901", 
                      "name": "洛阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180902", 
                      "name": "新安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180903", 
                      "name": "孟津"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180904", 
                      "name": "宜阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180905", 
                      "name": "洛宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180906", 
                      "name": "伊川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180907", 
                      "name": "嵩县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180908", 
                      "name": "偃师"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180909", 
                      "name": "栾川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180910", 
                      "name": "汝阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101180911", 
                      "name": "吉利"
                  }
              ], 
              "code": "101180901", 
              "name": "洛阳"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101181001", 
                      "name": "商丘"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181003", 
                      "name": "睢县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181004", 
                      "name": "民权"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181005", 
                      "name": "虞城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181006", 
                      "name": "柘城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181007", 
                      "name": "宁陵"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181008", 
                      "name": "夏邑"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181009", 
                      "name": "永城"
                  }
              ], 
              "code": "101181001", 
              "name": "商丘"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101181101", 
                      "name": "焦作"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181102", 
                      "name": "修武"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181103", 
                      "name": "武陟"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181104", 
                      "name": "沁阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181106", 
                      "name": "博爱"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181107", 
                      "name": "温县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181108", 
                      "name": "孟州"
                  }
              ], 
              "code": "101181101", 
              "name": "焦作"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101181201", 
                      "name": "鹤壁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181202", 
                      "name": "浚县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181203", 
                      "name": "淇县"
                  }
              ], 
              "code": "101181201", 
              "name": "鹤壁"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101181301", 
                      "name": "濮阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181302", 
                      "name": "台前"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181303", 
                      "name": "南乐"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181304", 
                      "name": "清丰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181305", 
                      "name": "范县"
                  }
              ], 
              "code": "101181301", 
              "name": "濮阳"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101181401", 
                      "name": "周口"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181402", 
                      "name": "扶沟"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181403", 
                      "name": "太康"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181404", 
                      "name": "淮阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181405", 
                      "name": "西华"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181406", 
                      "name": "商水"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181407", 
                      "name": "项城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181408", 
                      "name": "郸城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181409", 
                      "name": "鹿邑"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181410", 
                      "name": "沈丘"
                  }
              ], 
              "code": "101181401", 
              "name": "周口"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101181501", 
                      "name": "漯河"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181502", 
                      "name": "临颍"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181503", 
                      "name": "舞阳"
                  }
              ], 
              "code": "101181501", 
              "name": "漯河"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101181601", 
                      "name": "驻马店"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181602", 
                      "name": "西平"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181603", 
                      "name": "遂平"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181604", 
                      "name": "上蔡"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181605", 
                      "name": "汝南"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181606", 
                      "name": "泌阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181607", 
                      "name": "平舆"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181608", 
                      "name": "新蔡"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181609", 
                      "name": "确山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181610", 
                      "name": "正阳"
                  }
              ], 
              "code": "101181601", 
              "name": "驻马店"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101181701", 
                      "name": "三门峡"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181702", 
                      "name": "灵宝"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181703", 
                      "name": "渑池"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181704", 
                      "name": "卢氏"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181705", 
                      "name": "义马"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101181706", 
                      "name": "陕县"
                  }
              ], 
              "code": "101181701", 
              "name": "三门峡"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101181801", 
                      "name": "济源"
                  }
              ], 
              "code": "101181801", 
              "name": "济源"
          }
      ], 
      "code": "101180101", 
      "name": "河南"
  }, 
  {
      "cities": [
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101190101", 
                      "name": "南京"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190102", 
                      "name": "溧水"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190103", 
                      "name": "高淳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190104", 
                      "name": "江宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190105", 
                      "name": "六合"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190106", 
                      "name": "江浦"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190107", 
                      "name": "浦口"
                  }
              ], 
              "code": "101190101", 
              "name": "南京"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101190201", 
                      "name": "无锡"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190202", 
                      "name": "江阴"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190203", 
                      "name": "宜兴"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190204", 
                      "name": "锡山"
                  }
              ], 
              "code": "101190201", 
              "name": "无锡"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101190301", 
                      "name": "镇江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190302", 
                      "name": "丹阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190303", 
                      "name": "扬中"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190304", 
                      "name": "句容"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190305", 
                      "name": "丹徒"
                  }
              ], 
              "code": "101190301", 
              "name": "镇江"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101190401", 
                      "name": "苏州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190402", 
                      "name": "常熟"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190403", 
                      "name": "张家港"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190404", 
                      "name": "昆山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190405", 
                      "name": "吴中"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190407", 
                      "name": "吴江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190408", 
                      "name": "太仓"
                  }
              ], 
              "code": "101190401", 
              "name": "苏州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101190501", 
                      "name": "南通"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190502", 
                      "name": "海安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190503", 
                      "name": "如皋"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190504", 
                      "name": "如东"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190507", 
                      "name": "启东"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190508", 
                      "name": "海门"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190509", 
                      "name": "通州"
                  }
              ], 
              "code": "101190501", 
              "name": "南通"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101190601", 
                      "name": "扬州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190602", 
                      "name": "宝应"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190603", 
                      "name": "仪征"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190604", 
                      "name": "高邮"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190605", 
                      "name": "江都"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190606", 
                      "name": "邗江"
                  }
              ], 
              "code": "101190601", 
              "name": "扬州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101190701", 
                      "name": "盐城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190702", 
                      "name": "响水"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190703", 
                      "name": "滨海"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190704", 
                      "name": "阜宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190705", 
                      "name": "射阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190706", 
                      "name": "建湖"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190707", 
                      "name": "东台"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190708", 
                      "name": "大丰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190709", 
                      "name": "盐都"
                  }
              ], 
              "code": "101190701", 
              "name": "盐城"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101190801", 
                      "name": "徐州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190802", 
                      "name": "铜山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190803", 
                      "name": "丰县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190804", 
                      "name": "沛县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190805", 
                      "name": "邳州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190806", 
                      "name": "睢宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190807", 
                      "name": "新沂"
                  }
              ], 
              "code": "101190801", 
              "name": "徐州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101190901", 
                      "name": "淮安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190902", 
                      "name": "金湖"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190903", 
                      "name": "盱眙"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190904", 
                      "name": "洪泽"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190905", 
                      "name": "涟水"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190906", 
                      "name": "淮阴区"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101190908", 
                      "name": "淮安区"
                  }
              ], 
              "code": "101190901", 
              "name": "淮安"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101191001", 
                      "name": "连云港"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101191002", 
                      "name": "东海"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101191003", 
                      "name": "赣榆"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101191004", 
                      "name": "灌云"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101191005", 
                      "name": "灌南"
                  }
              ], 
              "code": "101191001", 
              "name": "连云港"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101191101", 
                      "name": "常州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101191102", 
                      "name": "溧阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101191103", 
                      "name": "金坛"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101191104", 
                      "name": "武进"
                  }
              ], 
              "code": "101191101", 
              "name": "常州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101191201", 
                      "name": "泰州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101191202", 
                      "name": "兴化"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101191203", 
                      "name": "泰兴"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101191204", 
                      "name": "姜堰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101191205", 
                      "name": "靖江"
                  }
              ], 
              "code": "101191201", 
              "name": "泰州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101191301", 
                      "name": "宿迁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101191302", 
                      "name": "沭阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101191303", 
                      "name": "泗阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101191304", 
                      "name": "泗洪"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101191305", 
                      "name": "宿豫"
                  }
              ], 
              "code": "101191301", 
              "name": "宿迁"
          }
      ], 
      "code": "101190101", 
      "name": "江苏"
  }, 
  {
      "cities": [
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101200101", 
                      "name": "武汉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200102", 
                      "name": "蔡甸"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200103", 
                      "name": "黄陂"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200104", 
                      "name": "新洲"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200105", 
                      "name": "江夏"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200106", 
                      "name": "东西湖"
                  }
              ], 
              "code": "101200101", 
              "name": "武汉"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101200201", 
                      "name": "襄阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200202", 
                      "name": "襄州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200203", 
                      "name": "保康"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200204", 
                      "name": "南漳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200205", 
                      "name": "宜城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200206", 
                      "name": "老河口"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200207", 
                      "name": "谷城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200208", 
                      "name": "枣阳"
                  }
              ], 
              "code": "101200201", 
              "name": "襄阳"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101200301", 
                      "name": "鄂州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200302", 
                      "name": "梁子湖"
                  }
              ], 
              "code": "101200301", 
              "name": "鄂州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101200401", 
                      "name": "孝感"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200402", 
                      "name": "安陆"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200403", 
                      "name": "云梦"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200404", 
                      "name": "大悟"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200405", 
                      "name": "应城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200406", 
                      "name": "汉川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200407", 
                      "name": "孝昌"
                  }
              ], 
              "code": "101200401", 
              "name": "孝感"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101200501", 
                      "name": "黄冈"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200502", 
                      "name": "红安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200503", 
                      "name": "麻城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200504", 
                      "name": "罗田"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200505", 
                      "name": "英山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200506", 
                      "name": "浠水"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200507", 
                      "name": "蕲春"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200508", 
                      "name": "黄梅"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200509", 
                      "name": "武穴"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200510", 
                      "name": "团风"
                  }
              ], 
              "code": "101200501", 
              "name": "黄冈"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101200601", 
                      "name": "黄石"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200602", 
                      "name": "大冶"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200603", 
                      "name": "阳新"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200604", 
                      "name": "铁山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200605", 
                      "name": "下陆"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200606", 
                      "name": "西塞山"
                  }
              ], 
              "code": "101200601", 
              "name": "黄石"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101200701", 
                      "name": "咸宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200702", 
                      "name": "赤壁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200703", 
                      "name": "嘉鱼"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200704", 
                      "name": "崇阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200705", 
                      "name": "通城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200706", 
                      "name": "通山"
                  }
              ], 
              "code": "101200701", 
              "name": "咸宁"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101200801", 
                      "name": "荆州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200802", 
                      "name": "江陵"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200803", 
                      "name": "公安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200804", 
                      "name": "石首"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200805", 
                      "name": "监利"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200806", 
                      "name": "洪湖"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200807", 
                      "name": "松滋"
                  }
              ], 
              "code": "101200801", 
              "name": "荆州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101200901", 
                      "name": "宜昌"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200902", 
                      "name": "远安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200903", 
                      "name": "秭归"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200904", 
                      "name": "兴山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200905", 
                      "name": "宜昌县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200906", 
                      "name": "五峰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200907", 
                      "name": "当阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200908", 
                      "name": "长阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200909", 
                      "name": "宜都"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200910", 
                      "name": "枝江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200911", 
                      "name": "三峡"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101200912", 
                      "name": "夷陵"
                  }
              ], 
              "code": "101200901", 
              "name": "宜昌"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101201001", 
                      "name": "恩施"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101201002", 
                      "name": "利川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101201003", 
                      "name": "建始"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101201004", 
                      "name": "咸丰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101201005", 
                      "name": "宣恩"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101201006", 
                      "name": "鹤峰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101201007", 
                      "name": "来凤"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101201008", 
                      "name": "巴东"
                  }
              ], 
              "code": "101201001", 
              "name": "恩施"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101201101", 
                      "name": "十堰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101201102", 
                      "name": "竹溪"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101201103", 
                      "name": "郧西"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101201104", 
                      "name": "郧县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101201105", 
                      "name": "竹山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101201106", 
                      "name": "房县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101201107", 
                      "name": "丹江口"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101201108", 
                      "name": "茅箭"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101201109", 
                      "name": "张湾"
                  }
              ], 
              "code": "101201101", 
              "name": "十堰"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101201201", 
                      "name": "神农架"
                  }
              ], 
              "code": "101201201", 
              "name": "神农架"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101201301", 
                      "name": "随州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101201302", 
                      "name": "广水"
                  }
              ], 
              "code": "101201301", 
              "name": "随州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101201401", 
                      "name": "荆门"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101201402", 
                      "name": "钟祥"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101201403", 
                      "name": "京山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101201404", 
                      "name": "掇刀"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101201405", 
                      "name": "沙洋"
                  }
              ], 
              "code": "101201401", 
              "name": "荆门"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101201406", 
                      "name": "沙市"
                  }
              ], 
              "code": "101201406", 
              "name": "荆州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101201501", 
                      "name": "天门"
                  }
              ], 
              "code": "101201501", 
              "name": "天门"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101201601", 
                      "name": "仙桃"
                  }
              ], 
              "code": "101201601", 
              "name": "仙桃"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101201701", 
                      "name": "潜江"
                  }
              ], 
              "code": "101201701", 
              "name": "潜江"
          }
      ], 
      "code": "101200101", 
      "name": "湖北"
  }, 
  {
      "cities": [
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101210101", 
                      "name": "杭州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210102", 
                      "name": "萧山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210103", 
                      "name": "桐庐"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210104", 
                      "name": "淳安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210105", 
                      "name": "建德"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210106", 
                      "name": "余杭"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210107", 
                      "name": "临安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210108", 
                      "name": "富阳"
                  }
              ], 
              "code": "101210101", 
              "name": "杭州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101210201", 
                      "name": "湖州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210202", 
                      "name": "长兴"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210203", 
                      "name": "安吉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210204", 
                      "name": "德清"
                  }
              ], 
              "code": "101210201", 
              "name": "湖州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101210301", 
                      "name": "嘉兴"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210302", 
                      "name": "嘉善"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210303", 
                      "name": "海宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210304", 
                      "name": "桐乡"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210305", 
                      "name": "平湖"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210306", 
                      "name": "海盐"
                  }
              ], 
              "code": "101210301", 
              "name": "嘉兴"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101210401", 
                      "name": "宁波"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210403", 
                      "name": "慈溪"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210404", 
                      "name": "余姚"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210405", 
                      "name": "奉化"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210406", 
                      "name": "象山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210408", 
                      "name": "宁海"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210410", 
                      "name": "北仑"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210411", 
                      "name": "鄞州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210412", 
                      "name": "镇海"
                  }
              ], 
              "code": "101210401", 
              "name": "宁波"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101210501", 
                      "name": "绍兴"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210502", 
                      "name": "诸暨"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210503", 
                      "name": "上虞"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210504", 
                      "name": "新昌"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210505", 
                      "name": "嵊州"
                  }
              ], 
              "code": "101210501", 
              "name": "绍兴"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101210601", 
                      "name": "台州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210603", 
                      "name": "玉环"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210604", 
                      "name": "三门"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210605", 
                      "name": "天台"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210606", 
                      "name": "仙居"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210607", 
                      "name": "温岭"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210609", 
                      "name": "洪家"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210610", 
                      "name": "临海"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210611", 
                      "name": "椒江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210612", 
                      "name": "黄岩"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210613", 
                      "name": "路桥"
                  }
              ], 
              "code": "101210601", 
              "name": "台州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101210701", 
                      "name": "温州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210702", 
                      "name": "泰顺"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210703", 
                      "name": "文成"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210704", 
                      "name": "平阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210705", 
                      "name": "瑞安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210706", 
                      "name": "洞头"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210707", 
                      "name": "乐清"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210708", 
                      "name": "永嘉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210709", 
                      "name": "苍南"
                  }
              ], 
              "code": "101210701", 
              "name": "温州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101210801", 
                      "name": "丽水"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210802", 
                      "name": "遂昌"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210803", 
                      "name": "龙泉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210804", 
                      "name": "缙云"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210805", 
                      "name": "青田"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210806", 
                      "name": "云和"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210807", 
                      "name": "庆元"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210808", 
                      "name": "松阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210809", 
                      "name": "景宁"
                  }
              ], 
              "code": "101210801", 
              "name": "丽水"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101210901", 
                      "name": "金华"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210902", 
                      "name": "浦江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210903", 
                      "name": "兰溪"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210904", 
                      "name": "义乌"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210905", 
                      "name": "东阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210906", 
                      "name": "武义"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210907", 
                      "name": "永康"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101210908", 
                      "name": "磐安"
                  }
              ], 
              "code": "101210901", 
              "name": "金华"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101211001", 
                      "name": "衢州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101211002", 
                      "name": "常山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101211003", 
                      "name": "开化"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101211004", 
                      "name": "龙游"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101211005", 
                      "name": "江山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101211006", 
                      "name": "衢江"
                  }
              ], 
              "code": "101211001", 
              "name": "衢州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101211101", 
                      "name": "舟山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101211102", 
                      "name": "嵊泗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101211104", 
                      "name": "岱山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101211105", 
                      "name": "普陀"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101211106", 
                      "name": "定海"
                  }
              ], 
              "code": "101211101", 
              "name": "舟山"
          }
      ], 
      "code": "101210101", 
      "name": "浙江"
  }, 
  {
      "cities": [
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101220101", 
                      "name": "合肥"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101220102", 
                      "name": "长丰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101220103", 
                      "name": "肥东"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101220104", 
                      "name": "肥西"
                  }
              ], 
              "code": "101220101", 
              "name": "合肥"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101220201", 
                      "name": "蚌埠"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101220202", 
                      "name": "怀远"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101220203", 
                      "name": "固镇"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101220204", 
                      "name": "五河"
                  }
              ], 
              "code": "101220201", 
              "name": "蚌埠"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101220301", 
                      "name": "芜湖"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101220302", 
                      "name": "繁昌"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101220303", 
                      "name": "芜湖县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101220304", 
                      "name": "南陵"
                  }
              ], 
              "code": "101220301", 
              "name": "芜湖"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101220401", 
                      "name": "淮南"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101220402", 
                      "name": "凤台"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101220403", 
                      "name": "潘集"
                  }
              ], 
              "code": "101220401", 
              "name": "淮南"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101220501", 
                      "name": "马鞍山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101220502", 
                      "name": "当涂"
                  }
              ], 
              "code": "101220501", 
              "name": "马鞍山"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101220601", 
                      "name": "安庆"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101220602", 
                      "name": "枞阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101220603", 
                      "name": "太湖"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101220604", 
                      "name": "潜山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101220605", 
                      "name": "怀宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101220606", 
                      "name": "宿松"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101220607", 
                      "name": "望江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101220608", 
                      "name": "岳西"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101220609", 
                      "name": "桐城"
                  }
              ], 
              "code": "101220601", 
              "name": "安庆"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101220701", 
                      "name": "宿州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101220702", 
                      "name": "砀山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101220703", 
                      "name": "灵璧"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101220704", 
                      "name": "泗县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101220705", 
                      "name": "萧县"
                  }
              ], 
              "code": "101220701", 
              "name": "宿州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101220801", 
                      "name": "阜阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101220802", 
                      "name": "阜南"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101220803", 
                      "name": "颍上"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101220804", 
                      "name": "临泉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101220805", 
                      "name": "界首"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101220806", 
                      "name": "太和"
                  }
              ], 
              "code": "101220801", 
              "name": "阜阳"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101220901", 
                      "name": "亳州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101220902", 
                      "name": "涡阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101220903", 
                      "name": "利辛"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101220904", 
                      "name": "蒙城"
                  }
              ], 
              "code": "101220901", 
              "name": "亳州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101221001", 
                      "name": "黄山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101221002", 
                      "name": "黄山区"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101221003", 
                      "name": "屯溪"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101221004", 
                      "name": "祁门"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101221005", 
                      "name": "黟县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101221006", 
                      "name": "歙县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101221007", 
                      "name": "休宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101221008", 
                      "name": "黄山风景区"
                  }
              ], 
              "code": "101221001", 
              "name": "黄山"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101221101", 
                      "name": "滁州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101221102", 
                      "name": "凤阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101221103", 
                      "name": "明光"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101221104", 
                      "name": "定远"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101221105", 
                      "name": "全椒"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101221106", 
                      "name": "来安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101221107", 
                      "name": "天长"
                  }
              ], 
              "code": "101221101", 
              "name": "滁州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101221201", 
                      "name": "淮北"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101221202", 
                      "name": "濉溪"
                  }
              ], 
              "code": "101221201", 
              "name": "淮北"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101221301", 
                      "name": "铜陵"
                  }
              ], 
              "code": "101221301", 
              "name": "铜陵"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101221401", 
                      "name": "宣城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101221402", 
                      "name": "泾县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101221403", 
                      "name": "旌德"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101221404", 
                      "name": "宁国"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101221405", 
                      "name": "绩溪"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101221406", 
                      "name": "广德"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101221407", 
                      "name": "郎溪"
                  }
              ], 
              "code": "101221401", 
              "name": "宣城"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101221501", 
                      "name": "六安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101221502", 
                      "name": "霍邱"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101221503", 
                      "name": "寿县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101221505", 
                      "name": "金寨"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101221506", 
                      "name": "霍山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101221507", 
                      "name": "舒城"
                  }
              ], 
              "code": "101221501", 
              "name": "六安"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101221601", 
                      "name": "巢湖"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101221602", 
                      "name": "庐江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101221603", 
                      "name": "无为"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101221604", 
                      "name": "含山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101221605", 
                      "name": "和县"
                  }
              ], 
              "code": "101221601", 
              "name": "巢湖"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101221701", 
                      "name": "池州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101221702", 
                      "name": "东至"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101221703", 
                      "name": "青阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101221704", 
                      "name": "九华山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101221705", 
                      "name": "石台"
                  }
              ], 
              "code": "101221701", 
              "name": "池州"
          }
      ], 
      "code": "101220101", 
      "name": "安徽"
  }, 
  {
      "cities": [
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101230101", 
                      "name": "福州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230102", 
                      "name": "闽清"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230103", 
                      "name": "闽侯"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230104", 
                      "name": "罗源"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230105", 
                      "name": "连江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230107", 
                      "name": "永泰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230108", 
                      "name": "平潭"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230110", 
                      "name": "长乐"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230111", 
                      "name": "福清"
                  }
              ], 
              "code": "101230101", 
              "name": "福州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101230201", 
                      "name": "厦门"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230202", 
                      "name": "同安"
                  }
              ], 
              "code": "101230201", 
              "name": "厦门"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101230301", 
                      "name": "宁德"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230302", 
                      "name": "古田"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230303", 
                      "name": "霞浦"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230304", 
                      "name": "寿宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230305", 
                      "name": "周宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230306", 
                      "name": "福安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230307", 
                      "name": "柘荣"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230308", 
                      "name": "福鼎"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230309", 
                      "name": "屏南"
                  }
              ], 
              "code": "101230301", 
              "name": "宁德"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101230401", 
                      "name": "莆田"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230402", 
                      "name": "仙游"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230403", 
                      "name": "秀屿港"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230404", 
                      "name": "涵江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230405", 
                      "name": "秀屿"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230406", 
                      "name": "荔城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230407", 
                      "name": "城厢"
                  }
              ], 
              "code": "101230401", 
              "name": "莆田"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101230501", 
                      "name": "泉州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230502", 
                      "name": "安溪"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230504", 
                      "name": "永春"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230505", 
                      "name": "德化"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230506", 
                      "name": "南安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230507", 
                      "name": "崇武"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230508", 
                      "name": "惠安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230509", 
                      "name": "晋江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230510", 
                      "name": "石狮"
                  }
              ], 
              "code": "101230501", 
              "name": "泉州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101230601", 
                      "name": "漳州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230602", 
                      "name": "长泰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230603", 
                      "name": "南靖"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230604", 
                      "name": "平和"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230605", 
                      "name": "龙海"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230606", 
                      "name": "漳浦"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230607", 
                      "name": "诏安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230608", 
                      "name": "东山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230609", 
                      "name": "云霄"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230610", 
                      "name": "华安"
                  }
              ], 
              "code": "101230601", 
              "name": "漳州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101230701", 
                      "name": "龙岩"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230702", 
                      "name": "长汀"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230703", 
                      "name": "连城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230704", 
                      "name": "武平"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230705", 
                      "name": "上杭"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230706", 
                      "name": "永定"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230707", 
                      "name": "漳平"
                  }
              ], 
              "code": "101230701", 
              "name": "龙岩"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101230801", 
                      "name": "三明"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230802", 
                      "name": "宁化"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230803", 
                      "name": "清流"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230804", 
                      "name": "泰宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230805", 
                      "name": "将乐"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230806", 
                      "name": "建宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230807", 
                      "name": "明溪"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230808", 
                      "name": "沙县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230809", 
                      "name": "尤溪"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230810", 
                      "name": "永安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230811", 
                      "name": "大田"
                  }
              ], 
              "code": "101230801", 
              "name": "三明"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101230901", 
                      "name": "南平"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230902", 
                      "name": "顺昌"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230903", 
                      "name": "光泽"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230904", 
                      "name": "邵武"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230905", 
                      "name": "武夷山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230906", 
                      "name": "浦城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230907", 
                      "name": "建阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230908", 
                      "name": "松溪"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230909", 
                      "name": "政和"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101230910", 
                      "name": "建瓯"
                  }
              ], 
              "code": "101230901", 
              "name": "南平"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101231001", 
                      "name": "钓鱼岛"
                  }
              ], 
              "code": "101231001", 
              "name": "钓鱼岛"
          }
      ], 
      "code": "101230101", 
      "name": "福建"
  }, 
  {
      "cities": [
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101240101", 
                      "name": "南昌"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240102", 
                      "name": "新建"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240103", 
                      "name": "南昌县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240104", 
                      "name": "安义"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240105", 
                      "name": "进贤"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240106", 
                      "name": "莲塘"
                  }
              ], 
              "code": "101240101", 
              "name": "南昌"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101240201", 
                      "name": "九江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240202", 
                      "name": "瑞昌"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240203", 
                      "name": "庐山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240204", 
                      "name": "武宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240205", 
                      "name": "德安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240206", 
                      "name": "永修"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240207", 
                      "name": "湖口"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240208", 
                      "name": "彭泽"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240209", 
                      "name": "星子"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240210", 
                      "name": "都昌"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240212", 
                      "name": "修水"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240213", 
                      "name": "澎泽"
                  }
              ], 
              "code": "101240201", 
              "name": "九江"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101240301", 
                      "name": "上饶"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240302", 
                      "name": "鄱阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240303", 
                      "name": "婺源"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240305", 
                      "name": "余干"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240306", 
                      "name": "万年"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240307", 
                      "name": "德兴"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240308", 
                      "name": "上饶县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240309", 
                      "name": "弋阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240310", 
                      "name": "横峰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240311", 
                      "name": "铅山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240312", 
                      "name": "玉山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240313", 
                      "name": "广丰"
                  }
              ], 
              "code": "101240301", 
              "name": "上饶"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101240401", 
                      "name": "抚州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240402", 
                      "name": "广昌"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240403", 
                      "name": "乐安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240404", 
                      "name": "崇仁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240405", 
                      "name": "金溪"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240406", 
                      "name": "资溪"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240407", 
                      "name": "宜黄"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240408", 
                      "name": "南城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240409", 
                      "name": "南丰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240410", 
                      "name": "黎川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240411", 
                      "name": "东乡"
                  }
              ], 
              "code": "101240401", 
              "name": "抚州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101240501", 
                      "name": "宜春"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240502", 
                      "name": "铜鼓"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240503", 
                      "name": "宜丰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240504", 
                      "name": "万载"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240505", 
                      "name": "上高"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240506", 
                      "name": "靖安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240507", 
                      "name": "奉新"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240508", 
                      "name": "高安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240509", 
                      "name": "樟树"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240510", 
                      "name": "丰城"
                  }
              ], 
              "code": "101240501", 
              "name": "宜春"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101240601", 
                      "name": "吉安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240602", 
                      "name": "吉安县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240603", 
                      "name": "吉水"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240604", 
                      "name": "新干"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240605", 
                      "name": "峡江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240606", 
                      "name": "永丰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240607", 
                      "name": "永新"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240608", 
                      "name": "井冈山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240609", 
                      "name": "万安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240610", 
                      "name": "遂川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240611", 
                      "name": "泰和"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240612", 
                      "name": "安福"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240613", 
                      "name": "宁冈"
                  }
              ], 
              "code": "101240601", 
              "name": "吉安"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101240701", 
                      "name": "赣州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240702", 
                      "name": "崇义"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240703", 
                      "name": "上犹"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240704", 
                      "name": "南康"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240705", 
                      "name": "大余"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240706", 
                      "name": "信丰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240707", 
                      "name": "宁都"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240708", 
                      "name": "石城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240709", 
                      "name": "瑞金"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240710", 
                      "name": "于都"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240711", 
                      "name": "会昌"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240712", 
                      "name": "安远"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240713", 
                      "name": "全南"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240714", 
                      "name": "龙南"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240715", 
                      "name": "定南"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240716", 
                      "name": "寻乌"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240717", 
                      "name": "兴国"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240718", 
                      "name": "赣县"
                  }
              ], 
              "code": "101240701", 
              "name": "赣州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101240801", 
                      "name": "景德镇"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240802", 
                      "name": "乐平"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240803", 
                      "name": "浮梁"
                  }
              ], 
              "code": "101240801", 
              "name": "景德镇"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101240901", 
                      "name": "萍乡"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240902", 
                      "name": "莲花"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240903", 
                      "name": "上栗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240904", 
                      "name": "安源"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240905", 
                      "name": "芦溪"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101240906", 
                      "name": "湘东"
                  }
              ], 
              "code": "101240901", 
              "name": "萍乡"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101241001", 
                      "name": "新余"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101241002", 
                      "name": "分宜"
                  }
              ], 
              "code": "101241001", 
              "name": "新余"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101241101", 
                      "name": "鹰潭"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101241102", 
                      "name": "余江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101241103", 
                      "name": "贵溪"
                  }
              ], 
              "code": "101241101", 
              "name": "鹰潭"
          }
      ], 
      "code": "101240101", 
      "name": "江西"
  }, 
  {
      "cities": [
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101250101", 
                      "name": "长沙"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250102", 
                      "name": "宁乡"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250103", 
                      "name": "浏阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250104", 
                      "name": "马坡岭"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250105", 
                      "name": "望城"
                  }
              ], 
              "code": "101250101", 
              "name": "长沙"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101250201", 
                      "name": "湘潭"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250202", 
                      "name": "韶山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250203", 
                      "name": "湘乡"
                  }
              ], 
              "code": "101250201", 
              "name": "湘潭"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101250301", 
                      "name": "株洲"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250302", 
                      "name": "攸县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250303", 
                      "name": "醴陵"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250305", 
                      "name": "茶陵"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250306", 
                      "name": "炎陵"
                  }
              ], 
              "code": "101250301", 
              "name": "株洲"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101250401", 
                      "name": "衡阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250402", 
                      "name": "衡山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250403", 
                      "name": "衡东"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250404", 
                      "name": "祁东"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250405", 
                      "name": "衡阳县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250406", 
                      "name": "常宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250407", 
                      "name": "衡南"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250408", 
                      "name": "耒阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250409", 
                      "name": "南岳"
                  }
              ], 
              "code": "101250401", 
              "name": "衡阳"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101250501", 
                      "name": "郴州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250502", 
                      "name": "桂阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250503", 
                      "name": "嘉禾"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250504", 
                      "name": "宜章"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250505", 
                      "name": "临武"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250507", 
                      "name": "资兴"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250508", 
                      "name": "汝城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250509", 
                      "name": "安仁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250510", 
                      "name": "永兴"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250511", 
                      "name": "桂东"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250512", 
                      "name": "苏仙"
                  }
              ], 
              "code": "101250501", 
              "name": "郴州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101250601", 
                      "name": "常德"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250602", 
                      "name": "安乡"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250603", 
                      "name": "桃源"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250604", 
                      "name": "汉寿"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250605", 
                      "name": "澧县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250606", 
                      "name": "临澧"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250607", 
                      "name": "石门"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250608", 
                      "name": "津市"
                  }
              ], 
              "code": "101250601", 
              "name": "常德"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101250700", 
                      "name": "益阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250701", 
                      "name": "赫山区"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250702", 
                      "name": "南县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250703", 
                      "name": "桃江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250704", 
                      "name": "安化"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250705", 
                      "name": "沅江"
                  }
              ], 
              "code": "101250700", 
              "name": "益阳"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101250801", 
                      "name": "娄底"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250802", 
                      "name": "双峰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250803", 
                      "name": "冷水江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250805", 
                      "name": "新化"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250806", 
                      "name": "涟源"
                  }
              ], 
              "code": "101250801", 
              "name": "娄底"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101250901", 
                      "name": "邵阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250902", 
                      "name": "隆回"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250903", 
                      "name": "洞口"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250904", 
                      "name": "新邵"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250905", 
                      "name": "邵东"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250906", 
                      "name": "绥宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250907", 
                      "name": "新宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250908", 
                      "name": "武冈"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250909", 
                      "name": "城步"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101250910", 
                      "name": "邵阳县"
                  }
              ], 
              "code": "101250901", 
              "name": "邵阳"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101251001", 
                      "name": "岳阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101251002", 
                      "name": "华容"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101251003", 
                      "name": "湘阴"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101251004", 
                      "name": "汨罗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101251005", 
                      "name": "平江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101251006", 
                      "name": "临湘"
                  }
              ], 
              "code": "101251001", 
              "name": "岳阳"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101251101", 
                      "name": "张家界"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101251102", 
                      "name": "桑植"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101251103", 
                      "name": "慈利"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101251104", 
                      "name": "武陵源"
                  }
              ], 
              "code": "101251101", 
              "name": "张家界"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101251201", 
                      "name": "怀化"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101251203", 
                      "name": "沅陵"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101251204", 
                      "name": "辰溪"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101251205", 
                      "name": "靖州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101251206", 
                      "name": "会同"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101251207", 
                      "name": "通道"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101251208", 
                      "name": "麻阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101251209", 
                      "name": "新晃"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101251210", 
                      "name": "芷江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101251211", 
                      "name": "溆浦"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101251212", 
                      "name": "中方"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101251213", 
                      "name": "洪江"
                  }
              ], 
              "code": "101251201", 
              "name": "怀化"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101251401", 
                      "name": "永州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101251402", 
                      "name": "祁阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101251403", 
                      "name": "东安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101251404", 
                      "name": "双牌"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101251405", 
                      "name": "道县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101251406", 
                      "name": "宁远"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101251407", 
                      "name": "江永"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101251408", 
                      "name": "蓝山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101251409", 
                      "name": "新田"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101251410", 
                      "name": "江华"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101251411", 
                      "name": "冷水滩"
                  }
              ], 
              "code": "101251401", 
              "name": "永州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101251501", 
                      "name": "吉首"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101251502", 
                      "name": "保靖"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101251503", 
                      "name": "永顺"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101251504", 
                      "name": "古丈"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101251505", 
                      "name": "凤凰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101251506", 
                      "name": "泸溪"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101251507", 
                      "name": "龙山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101251508", 
                      "name": "花垣"
                  }
              ], 
              "code": "101251501", 
              "name": "湘西"
          }
      ], 
      "code": "101250101", 
      "name": "湖南"
  }, 
  {
      "cities": [
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101260101", 
                      "name": "贵阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260102", 
                      "name": "白云"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260103", 
                      "name": "花溪"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260104", 
                      "name": "乌当"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260105", 
                      "name": "息烽"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260106", 
                      "name": "开阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260107", 
                      "name": "修文"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260108", 
                      "name": "清镇"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260109", 
                      "name": "小河"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260110", 
                      "name": "云岩"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260111", 
                      "name": "南明"
                  }
              ], 
              "code": "101260101", 
              "name": "贵阳"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101260201", 
                      "name": "遵义"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260202", 
                      "name": "遵义县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260203", 
                      "name": "仁怀"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260204", 
                      "name": "绥阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260205", 
                      "name": "湄潭"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260206", 
                      "name": "凤冈"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260207", 
                      "name": "桐梓"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260208", 
                      "name": "赤水"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260209", 
                      "name": "习水"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260210", 
                      "name": "道真"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260211", 
                      "name": "正安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260212", 
                      "name": "务川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260213", 
                      "name": "余庆"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260214", 
                      "name": "汇川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260215", 
                      "name": "红花岗"
                  }
              ], 
              "code": "101260201", 
              "name": "遵义"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101260301", 
                      "name": "安顺"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260302", 
                      "name": "普定"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260303", 
                      "name": "镇宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260304", 
                      "name": "平坝"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260305", 
                      "name": "紫云"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260306", 
                      "name": "关岭"
                  }
              ], 
              "code": "101260301", 
              "name": "安顺"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101260401", 
                      "name": "都匀"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260402", 
                      "name": "贵定"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260403", 
                      "name": "瓮安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260404", 
                      "name": "长顺"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260405", 
                      "name": "福泉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260406", 
                      "name": "惠水"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260407", 
                      "name": "龙里"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260408", 
                      "name": "罗甸"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260409", 
                      "name": "平塘"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260410", 
                      "name": "独山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260411", 
                      "name": "三都"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260412", 
                      "name": "荔波"
                  }
              ], 
              "code": "101260401", 
              "name": "黔南"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101260501", 
                      "name": "凯里"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260502", 
                      "name": "岑巩"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260503", 
                      "name": "施秉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260504", 
                      "name": "镇远"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260505", 
                      "name": "黄平"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260507", 
                      "name": "麻江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260508", 
                      "name": "丹寨"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260509", 
                      "name": "三穗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260510", 
                      "name": "台江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260511", 
                      "name": "剑河"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260512", 
                      "name": "雷山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260513", 
                      "name": "黎平"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260514", 
                      "name": "天柱"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260515", 
                      "name": "锦屏"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260516", 
                      "name": "榕江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260517", 
                      "name": "从江"
                  }
              ], 
              "code": "101260501", 
              "name": "黔东南"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101260601", 
                      "name": "铜仁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260602", 
                      "name": "江口"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260603", 
                      "name": "玉屏"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260604", 
                      "name": "万山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260605", 
                      "name": "思南"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260607", 
                      "name": "印江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260608", 
                      "name": "石阡"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260609", 
                      "name": "沿河"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260610", 
                      "name": "德江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260611", 
                      "name": "松桃"
                  }
              ], 
              "code": "101260601", 
              "name": "铜仁"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101260701", 
                      "name": "毕节"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260702", 
                      "name": "赫章"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260703", 
                      "name": "金沙"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260704", 
                      "name": "威宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260705", 
                      "name": "大方"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260706", 
                      "name": "纳雍"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260707", 
                      "name": "织金"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260708", 
                      "name": "黔西"
                  }
              ], 
              "code": "101260701", 
              "name": "毕节"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101260801", 
                      "name": "水城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260802", 
                      "name": "六枝"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260804", 
                      "name": "盘县"
                  }
              ], 
              "code": "101260801", 
              "name": "六盘水"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101260901", 
                      "name": "兴义"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260902", 
                      "name": "晴隆"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260903", 
                      "name": "兴仁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260904", 
                      "name": "贞丰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260905", 
                      "name": "望谟"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260907", 
                      "name": "安龙"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260908", 
                      "name": "册亨"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101260909", 
                      "name": "普安"
                  }
              ], 
              "code": "101260901", 
              "name": "黔西南"
          }
      ], 
      "code": "101260101", 
      "name": "贵州"
  }, 
  {
      "cities": [
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101270101", 
                      "name": "成都"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270102", 
                      "name": "龙泉驿"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270103", 
                      "name": "新都"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270104", 
                      "name": "温江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270105", 
                      "name": "金堂"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270106", 
                      "name": "双流"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270107", 
                      "name": "郫县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270108", 
                      "name": "大邑"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270109", 
                      "name": "蒲江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270110", 
                      "name": "新津"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270111", 
                      "name": "都江堰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270112", 
                      "name": "彭州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270113", 
                      "name": "邛崃"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270114", 
                      "name": "崇州"
                  }
              ], 
              "code": "101270101", 
              "name": "成都"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101270201", 
                      "name": "攀枝花"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270202", 
                      "name": "仁和"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270203", 
                      "name": "米易"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270204", 
                      "name": "盐边"
                  }
              ], 
              "code": "101270201", 
              "name": "攀枝花"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101270301", 
                      "name": "自贡"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270302", 
                      "name": "富顺"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270303", 
                      "name": "荣县"
                  }
              ], 
              "code": "101270301", 
              "name": "自贡"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101270401", 
                      "name": "绵阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270402", 
                      "name": "三台"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270403", 
                      "name": "盐亭"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270404", 
                      "name": "安县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270405", 
                      "name": "梓潼"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270406", 
                      "name": "北川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270407", 
                      "name": "平武"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270408", 
                      "name": "江油"
                  }
              ], 
              "code": "101270401", 
              "name": "绵阳"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101270501", 
                      "name": "南充"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270502", 
                      "name": "南部"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270503", 
                      "name": "营山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270504", 
                      "name": "蓬安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270505", 
                      "name": "仪陇"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270506", 
                      "name": "西充"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270507", 
                      "name": "阆中"
                  }
              ], 
              "code": "101270501", 
              "name": "南充"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101270601", 
                      "name": "达州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270602", 
                      "name": "宣汉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270603", 
                      "name": "开江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270604", 
                      "name": "大竹"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270605", 
                      "name": "渠县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270606", 
                      "name": "万源"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270607", 
                      "name": "通川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270608", 
                      "name": "达县"
                  }
              ], 
              "code": "101270601", 
              "name": "达州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101270701", 
                      "name": "遂宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270702", 
                      "name": "蓬溪"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270703", 
                      "name": "射洪"
                  }
              ], 
              "code": "101270701", 
              "name": "遂宁"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101270801", 
                      "name": "广安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270802", 
                      "name": "岳池"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270803", 
                      "name": "武胜"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270804", 
                      "name": "邻水"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270805", 
                      "name": "华蓥"
                  }
              ], 
              "code": "101270801", 
              "name": "广安"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101270901", 
                      "name": "巴中"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270902", 
                      "name": "通江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270903", 
                      "name": "南江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101270904", 
                      "name": "平昌"
                  }
              ], 
              "code": "101270901", 
              "name": "巴中"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101271001", 
                      "name": "泸州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271003", 
                      "name": "泸县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271004", 
                      "name": "合江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271005", 
                      "name": "叙永"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271006", 
                      "name": "古蔺"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271007", 
                      "name": "纳溪"
                  }
              ], 
              "code": "101271001", 
              "name": "泸州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101271101", 
                      "name": "宜宾"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271103", 
                      "name": "宜宾县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271104", 
                      "name": "南溪"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271105", 
                      "name": "江安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271106", 
                      "name": "长宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271107", 
                      "name": "高县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271108", 
                      "name": "珙县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271109", 
                      "name": "筠连"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271110", 
                      "name": "兴文"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271111", 
                      "name": "屏山"
                  }
              ], 
              "code": "101271101", 
              "name": "宜宾"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101271201", 
                      "name": "内江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271202", 
                      "name": "东兴"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271203", 
                      "name": "威远"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271204", 
                      "name": "资中"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271205", 
                      "name": "隆昌"
                  }
              ], 
              "code": "101271201", 
              "name": "内江"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101271301", 
                      "name": "资阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271302", 
                      "name": "安岳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271303", 
                      "name": "乐至"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271304", 
                      "name": "简阳"
                  }
              ], 
              "code": "101271301", 
              "name": "资阳"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101271401", 
                      "name": "乐山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271402", 
                      "name": "犍为"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271403", 
                      "name": "井研"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271404", 
                      "name": "夹江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271405", 
                      "name": "沐川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271406", 
                      "name": "峨边"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271407", 
                      "name": "马边"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271408", 
                      "name": "峨眉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271409", 
                      "name": "峨眉山"
                  }
              ], 
              "code": "101271401", 
              "name": "乐山"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101271501", 
                      "name": "眉山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271502", 
                      "name": "仁寿"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271503", 
                      "name": "彭山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271504", 
                      "name": "洪雅"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271505", 
                      "name": "丹棱"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271506", 
                      "name": "青神"
                  }
              ], 
              "code": "101271501", 
              "name": "眉山"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101271601", 
                      "name": "凉山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271603", 
                      "name": "木里"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271604", 
                      "name": "盐源"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271605", 
                      "name": "德昌"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271606", 
                      "name": "会理"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271607", 
                      "name": "会东"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271608", 
                      "name": "宁南"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271609", 
                      "name": "普格"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271610", 
                      "name": "西昌"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271611", 
                      "name": "金阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271612", 
                      "name": "昭觉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271613", 
                      "name": "喜德"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271614", 
                      "name": "冕宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271615", 
                      "name": "越西"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271616", 
                      "name": "甘洛"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271617", 
                      "name": "雷波"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271618", 
                      "name": "美姑"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271619", 
                      "name": "布拖"
                  }
              ], 
              "code": "101271601", 
              "name": "凉山"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101271701", 
                      "name": "雅安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271702", 
                      "name": "名山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271703", 
                      "name": "荥经"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271704", 
                      "name": "汉源"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271705", 
                      "name": "石棉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271706", 
                      "name": "天全"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271707", 
                      "name": "芦山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271708", 
                      "name": "宝兴"
                  }
              ], 
              "code": "101271701", 
              "name": "雅安"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101271801", 
                      "name": "甘孜"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271802", 
                      "name": "康定"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271803", 
                      "name": "泸定"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271804", 
                      "name": "丹巴"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271805", 
                      "name": "九龙"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271806", 
                      "name": "雅江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271807", 
                      "name": "道孚"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271808", 
                      "name": "炉霍"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271809", 
                      "name": "新龙"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271810", 
                      "name": "德格"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271811", 
                      "name": "白玉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271812", 
                      "name": "石渠"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271813", 
                      "name": "色达"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271814", 
                      "name": "理塘"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271815", 
                      "name": "巴塘"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271816", 
                      "name": "乡城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271817", 
                      "name": "稻城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271818", 
                      "name": "得荣"
                  }
              ], 
              "code": "101271801", 
              "name": "甘孜"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101271901", 
                      "name": "阿坝"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271902", 
                      "name": "汶川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271903", 
                      "name": "理县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271904", 
                      "name": "茂县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271905", 
                      "name": "松潘"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271906", 
                      "name": "九寨沟"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271907", 
                      "name": "金川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271908", 
                      "name": "小金"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271909", 
                      "name": "黑水"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271910", 
                      "name": "马尔康"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271911", 
                      "name": "壤塘"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271912", 
                      "name": "若尔盖"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271913", 
                      "name": "红原"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101271914", 
                      "name": "南坪"
                  }
              ], 
              "code": "101271901", 
              "name": "阿坝"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101272001", 
                      "name": "德阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101272002", 
                      "name": "中江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101272003", 
                      "name": "广汉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101272004", 
                      "name": "什邡"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101272005", 
                      "name": "绵竹"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101272006", 
                      "name": "罗江"
                  }
              ], 
              "code": "101272001", 
              "name": "德阳"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101272101", 
                      "name": "广元"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101272102", 
                      "name": "旺苍"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101272103", 
                      "name": "青川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101272104", 
                      "name": "剑阁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101272105", 
                      "name": "苍溪"
                  }
              ], 
              "code": "101272101", 
              "name": "广元"
          }
      ], 
      "code": "101270101", 
      "name": "四川"
  }, 
  {
      "cities": [
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101280101", 
                      "name": "广州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280102", 
                      "name": "番禺"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280103", 
                      "name": "从化"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280104", 
                      "name": "增城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280105", 
                      "name": "花都"
                  }
              ], 
              "code": "101280101", 
              "name": "广州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101280201", 
                      "name": "韶关"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280202", 
                      "name": "乳源"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280203", 
                      "name": "始兴"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280204", 
                      "name": "翁源"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280205", 
                      "name": "乐昌"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280206", 
                      "name": "仁化"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280207", 
                      "name": "南雄"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280208", 
                      "name": "新丰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280209", 
                      "name": "曲江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280210", 
                      "name": "浈江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280211", 
                      "name": "武江"
                  }
              ], 
              "code": "101280201", 
              "name": "韶关"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101280301", 
                      "name": "惠州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280302", 
                      "name": "博罗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280303", 
                      "name": "惠阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280304", 
                      "name": "惠东"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280305", 
                      "name": "龙门"
                  }
              ], 
              "code": "101280301", 
              "name": "惠州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101280401", 
                      "name": "梅州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280402", 
                      "name": "兴宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280403", 
                      "name": "蕉岭"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280404", 
                      "name": "大埔"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280406", 
                      "name": "丰顺"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280407", 
                      "name": "平远"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280408", 
                      "name": "五华"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280409", 
                      "name": "梅县"
                  }
              ], 
              "code": "101280401", 
              "name": "梅州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101280501", 
                      "name": "汕头"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280502", 
                      "name": "潮阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280503", 
                      "name": "澄海"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280504", 
                      "name": "南澳"
                  }
              ], 
              "code": "101280501", 
              "name": "汕头"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101280601", 
                      "name": "深圳"
                  }
              ], 
              "code": "101280601", 
              "name": "深圳"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101280701", 
                      "name": "珠海"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280702", 
                      "name": "斗门"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280703", 
                      "name": "金湾"
                  }
              ], 
              "code": "101280701", 
              "name": "珠海"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101280800", 
                      "name": "佛山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280801", 
                      "name": "顺德"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280802", 
                      "name": "三水"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280803", 
                      "name": "南海"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280804", 
                      "name": "高明"
                  }
              ], 
              "code": "101280800", 
              "name": "佛山"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101280901", 
                      "name": "肇庆"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280902", 
                      "name": "广宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280903", 
                      "name": "四会"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280905", 
                      "name": "德庆"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280906", 
                      "name": "怀集"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280907", 
                      "name": "封开"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101280908", 
                      "name": "高要"
                  }
              ], 
              "code": "101280901", 
              "name": "肇庆"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101281001", 
                      "name": "湛江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281002", 
                      "name": "吴川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281003", 
                      "name": "雷州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281004", 
                      "name": "徐闻"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281005", 
                      "name": "廉江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281006", 
                      "name": "赤坎"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281007", 
                      "name": "遂溪"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281008", 
                      "name": "坡头"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281009", 
                      "name": "霞山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281010", 
                      "name": "麻章"
                  }
              ], 
              "code": "101281001", 
              "name": "湛江"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101281101", 
                      "name": "江门"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281103", 
                      "name": "开平"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281104", 
                      "name": "新会"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281105", 
                      "name": "恩平"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281106", 
                      "name": "台山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281107", 
                      "name": "蓬江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281108", 
                      "name": "鹤山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281109", 
                      "name": "江海"
                  }
              ], 
              "code": "101281101", 
              "name": "江门"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101281201", 
                      "name": "河源"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281202", 
                      "name": "紫金"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281203", 
                      "name": "连平"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281204", 
                      "name": "和平"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281205", 
                      "name": "龙川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281206", 
                      "name": "东源"
                  }
              ], 
              "code": "101281201", 
              "name": "河源"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101281301", 
                      "name": "清远"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281302", 
                      "name": "连南"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281303", 
                      "name": "连州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281304", 
                      "name": "连山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281305", 
                      "name": "阳山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281306", 
                      "name": "佛冈"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281307", 
                      "name": "英德"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281308", 
                      "name": "清新"
                  }
              ], 
              "code": "101281301", 
              "name": "清远"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101281401", 
                      "name": "云浮"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281402", 
                      "name": "罗定"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281403", 
                      "name": "新兴"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281404", 
                      "name": "郁南"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281406", 
                      "name": "云安"
                  }
              ], 
              "code": "101281401", 
              "name": "云浮"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101281501", 
                      "name": "潮州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281502", 
                      "name": "饶平"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281503", 
                      "name": "潮安"
                  }
              ], 
              "code": "101281501", 
              "name": "潮州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101281601", 
                      "name": "东莞"
                  }
              ], 
              "code": "101281601", 
              "name": "东莞"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101281701", 
                      "name": "中山"
                  }
              ], 
              "code": "101281701", 
              "name": "中山"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101281801", 
                      "name": "阳江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281802", 
                      "name": "阳春"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281803", 
                      "name": "阳东"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281804", 
                      "name": "阳西"
                  }
              ], 
              "code": "101281801", 
              "name": "阳江"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101281901", 
                      "name": "揭阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281902", 
                      "name": "揭西"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281903", 
                      "name": "普宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281904", 
                      "name": "惠来"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101281905", 
                      "name": "揭东"
                  }
              ], 
              "code": "101281901", 
              "name": "揭阳"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101282001", 
                      "name": "茂名"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101282002", 
                      "name": "高州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101282003", 
                      "name": "化州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101282004", 
                      "name": "电白"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101282005", 
                      "name": "信宜"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101282006", 
                      "name": "茂港"
                  }
              ], 
              "code": "101282001", 
              "name": "茂名"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101282101", 
                      "name": "汕尾"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101282102", 
                      "name": "海丰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101282103", 
                      "name": "陆丰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101282104", 
                      "name": "陆河"
                  }
              ], 
              "code": "101282101", 
              "name": "汕尾"
          }
      ], 
      "code": "101280101", 
      "name": "广东"
  }, 
  {
      "cities": [
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101290101", 
                      "name": "昆明"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290103", 
                      "name": "东川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290104", 
                      "name": "寻甸"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290105", 
                      "name": "晋宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290106", 
                      "name": "宜良"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290107", 
                      "name": "石林"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290108", 
                      "name": "呈贡"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290109", 
                      "name": "富民"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290110", 
                      "name": "嵩明"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290111", 
                      "name": "禄劝"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290112", 
                      "name": "安宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290113", 
                      "name": "太华山"
                  }
              ], 
              "code": "101290101", 
              "name": "昆明"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101290201", 
                      "name": "大理"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290202", 
                      "name": "云龙"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290203", 
                      "name": "漾濞"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290204", 
                      "name": "永平"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290205", 
                      "name": "宾川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290206", 
                      "name": "弥渡"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290207", 
                      "name": "祥云"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290208", 
                      "name": "巍山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290209", 
                      "name": "剑川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290210", 
                      "name": "洱源"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290211", 
                      "name": "鹤庆"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290212", 
                      "name": "南涧"
                  }
              ], 
              "code": "101290201", 
              "name": "大理"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101290301", 
                      "name": "红河"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290302", 
                      "name": "石屏"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290303", 
                      "name": "建水"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290304", 
                      "name": "弥勒"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290305", 
                      "name": "元阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290306", 
                      "name": "绿春"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290307", 
                      "name": "开远"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290308", 
                      "name": "个旧"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290309", 
                      "name": "蒙自"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290310", 
                      "name": "屏边"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290311", 
                      "name": "泸西"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290312", 
                      "name": "金平"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290313", 
                      "name": "河口"
                  }
              ], 
              "code": "101290301", 
              "name": "红河"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101290401", 
                      "name": "曲靖"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290402", 
                      "name": "沾益"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290403", 
                      "name": "陆良"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290404", 
                      "name": "富源"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290405", 
                      "name": "马龙"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290406", 
                      "name": "师宗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290407", 
                      "name": "罗平"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290408", 
                      "name": "会泽"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290409", 
                      "name": "宣威"
                  }
              ], 
              "code": "101290401", 
              "name": "曲靖"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101290501", 
                      "name": "保山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290503", 
                      "name": "龙陵"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290504", 
                      "name": "施甸"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290505", 
                      "name": "昌宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290506", 
                      "name": "腾冲"
                  }
              ], 
              "code": "101290501", 
              "name": "保山"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101290601", 
                      "name": "文山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290602", 
                      "name": "西畴"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290603", 
                      "name": "马关"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290604", 
                      "name": "麻栗坡"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290605", 
                      "name": "砚山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290606", 
                      "name": "丘北"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290607", 
                      "name": "广南"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290608", 
                      "name": "富宁"
                  }
              ], 
              "code": "101290601", 
              "name": "文山"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101290701", 
                      "name": "玉溪"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290702", 
                      "name": "澄江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290703", 
                      "name": "江川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290704", 
                      "name": "通海"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290705", 
                      "name": "华宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290706", 
                      "name": "新平"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290707", 
                      "name": "易门"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290708", 
                      "name": "峨山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290709", 
                      "name": "元江"
                  }
              ], 
              "code": "101290701", 
              "name": "玉溪"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101290801", 
                      "name": "楚雄"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290802", 
                      "name": "大姚"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290803", 
                      "name": "元谋"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290804", 
                      "name": "姚安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290805", 
                      "name": "牟定"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290806", 
                      "name": "南华"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290807", 
                      "name": "武定"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290808", 
                      "name": "禄丰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290809", 
                      "name": "双柏"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290810", 
                      "name": "永仁"
                  }
              ], 
              "code": "101290801", 
              "name": "楚雄"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101290901", 
                      "name": "普洱"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290902", 
                      "name": "景谷"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290903", 
                      "name": "景东"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290904", 
                      "name": "澜沧"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290906", 
                      "name": "墨江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290907", 
                      "name": "江城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290908", 
                      "name": "孟连"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290909", 
                      "name": "西盟"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290911", 
                      "name": "镇沅"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101290912", 
                      "name": "宁洱"
                  }
              ], 
              "code": "101290901", 
              "name": "普洱"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101291001", 
                      "name": "昭通"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101291002", 
                      "name": "鲁甸"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101291003", 
                      "name": "彝良"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101291004", 
                      "name": "镇雄"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101291005", 
                      "name": "威信"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101291006", 
                      "name": "巧家"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101291007", 
                      "name": "绥江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101291008", 
                      "name": "永善"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101291009", 
                      "name": "盐津"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101291010", 
                      "name": "大关"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101291011", 
                      "name": "水富"
                  }
              ], 
              "code": "101291001", 
              "name": "昭通"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101291101", 
                      "name": "临沧"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101291102", 
                      "name": "沧源"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101291103", 
                      "name": "耿马"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101291104", 
                      "name": "双江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101291105", 
                      "name": "凤庆"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101291106", 
                      "name": "永德"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101291107", 
                      "name": "云县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101291108", 
                      "name": "镇康"
                  }
              ], 
              "code": "101291101", 
              "name": "临沧"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101291201", 
                      "name": "怒江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101291203", 
                      "name": "福贡"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101291204", 
                      "name": "兰坪"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101291205", 
                      "name": "泸水"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101291206", 
                      "name": "六库"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101291207", 
                      "name": "贡山"
                  }
              ], 
              "code": "101291201", 
              "name": "怒江"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101291301", 
                      "name": "香格里拉"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101291302", 
                      "name": "德钦"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101291303", 
                      "name": "维西"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101291304", 
                      "name": "中甸"
                  }
              ], 
              "code": "101291301", 
              "name": "迪庆"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101291401", 
                      "name": "丽江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101291402", 
                      "name": "永胜"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101291403", 
                      "name": "华坪"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101291404", 
                      "name": "宁蒗"
                  }
              ], 
              "code": "101291401", 
              "name": "丽江"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101291501", 
                      "name": "德宏"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101291503", 
                      "name": "陇川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101291504", 
                      "name": "盈江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101291506", 
                      "name": "瑞丽"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101291507", 
                      "name": "梁河"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101291508", 
                      "name": "潞西"
                  }
              ], 
              "code": "101291501", 
              "name": "德宏"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101291601", 
                      "name": "景洪"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101291603", 
                      "name": "勐海"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101291605", 
                      "name": "勐腊"
                  }
              ], 
              "code": "101291601", 
              "name": "西双版纳"
          }
      ], 
      "code": "101290101", 
      "name": "云南"
  }, 
  {
      "cities": [
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101300101", 
                      "name": "南宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300103", 
                      "name": "邕宁"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300104", 
                      "name": "横县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300105", 
                      "name": "隆安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300106", 
                      "name": "马山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300107", 
                      "name": "上林"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300108", 
                      "name": "武鸣"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300109", 
                      "name": "宾阳"
                  }
              ], 
              "code": "101300101", 
              "name": "南宁"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101300201", 
                      "name": "崇左"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300202", 
                      "name": "天等"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300203", 
                      "name": "龙州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300204", 
                      "name": "凭祥"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300205", 
                      "name": "大新"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300206", 
                      "name": "扶绥"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300207", 
                      "name": "宁明"
                  }
              ], 
              "code": "101300201", 
              "name": "崇左"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101300301", 
                      "name": "柳州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300302", 
                      "name": "柳城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300304", 
                      "name": "鹿寨"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300305", 
                      "name": "柳江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300306", 
                      "name": "融安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300307", 
                      "name": "融水"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300308", 
                      "name": "三江"
                  }
              ], 
              "code": "101300301", 
              "name": "柳州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101300401", 
                      "name": "来宾"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300402", 
                      "name": "忻城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300403", 
                      "name": "金秀"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300404", 
                      "name": "象州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300405", 
                      "name": "武宣"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300406", 
                      "name": "合山"
                  }
              ], 
              "code": "101300401", 
              "name": "来宾"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101300501", 
                      "name": "桂林"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300503", 
                      "name": "龙胜"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300504", 
                      "name": "永福"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300505", 
                      "name": "临桂"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300506", 
                      "name": "兴安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300507", 
                      "name": "灵川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300508", 
                      "name": "全州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300509", 
                      "name": "灌阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300510", 
                      "name": "阳朔"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300511", 
                      "name": "恭城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300512", 
                      "name": "平乐"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300513", 
                      "name": "荔浦"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300514", 
                      "name": "资源"
                  }
              ], 
              "code": "101300501", 
              "name": "桂林"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101300601", 
                      "name": "梧州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300602", 
                      "name": "藤县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300604", 
                      "name": "苍梧"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300605", 
                      "name": "蒙山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300606", 
                      "name": "岑溪"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300607", 
                      "name": "长洲"
                  }
              ], 
              "code": "101300601", 
              "name": "梧州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101300701", 
                      "name": "贺州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300702", 
                      "name": "昭平"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300703", 
                      "name": "富川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300704", 
                      "name": "钟山"
                  }
              ], 
              "code": "101300701", 
              "name": "贺州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101300801", 
                      "name": "贵港"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300802", 
                      "name": "桂平"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300803", 
                      "name": "平南"
                  }
              ], 
              "code": "101300801", 
              "name": "贵港"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101300901", 
                      "name": "玉林"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300902", 
                      "name": "博白"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300903", 
                      "name": "北流"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300904", 
                      "name": "容县"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300905", 
                      "name": "陆川"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101300906", 
                      "name": "兴业"
                  }
              ], 
              "code": "101300901", 
              "name": "玉林"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101301001", 
                      "name": "百色"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101301002", 
                      "name": "那坡"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101301003", 
                      "name": "田阳"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101301004", 
                      "name": "德保"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101301005", 
                      "name": "靖西"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101301006", 
                      "name": "田东"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101301007", 
                      "name": "平果"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101301008", 
                      "name": "隆林"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101301009", 
                      "name": "西林"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101301010", 
                      "name": "乐业"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101301011", 
                      "name": "凌云"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101301012", 
                      "name": "田林"
                  }
              ], 
              "code": "101301001", 
              "name": "百色"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101301101", 
                      "name": "钦州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101301102", 
                      "name": "浦北"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101301103", 
                      "name": "灵山"
                  }
              ], 
              "code": "101301101", 
              "name": "钦州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101301201", 
                      "name": "河池"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101301202", 
                      "name": "天峨"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101301203", 
                      "name": "东兰"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101301204", 
                      "name": "巴马"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101301205", 
                      "name": "环江"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101301206", 
                      "name": "罗城"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101301207", 
                      "name": "宜州"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101301208", 
                      "name": "凤山"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101301209", 
                      "name": "南丹"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101301210", 
                      "name": "都安"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101301211", 
                      "name": "大化"
                  }
              ], 
              "code": "101301201", 
              "name": "河池"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101301301", 
                      "name": "北海"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101301302", 
                      "name": "合浦"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101301303", 
                      "name": "涠洲岛"
                  }
              ], 
              "code": "101301301", 
              "name": "北海"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101301401", 
                      "name": "防城港"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101301402", 
                      "name": "上思"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101301403", 
                      "name": "东兴"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101301405", 
                      "name": "防城"
                  }
              ], 
              "code": "101301401", 
              "name": "防城港"
          }
      ], 
      "code": "101300101", 
      "name": "广西"
  }, 
  {
      "cities": [
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101310101", 
                      "name": "海口"
                  }
              ], 
              "code": "101310101", 
              "name": "海口"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101310201", 
                      "name": "三亚"
                  }
              ], 
              "code": "101310201", 
              "name": "三亚"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101310202", 
                      "name": "东方"
                  }
              ], 
              "code": "101310202", 
              "name": "东方"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101310203", 
                      "name": "临高"
                  }
              ], 
              "code": "101310203", 
              "name": "临高"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101310204", 
                      "name": "澄迈"
                  }
              ], 
              "code": "101310204", 
              "name": "澄迈"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101310205", 
                      "name": "儋州"
                  }
              ], 
              "code": "101310205", 
              "name": "儋州"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101310206", 
                      "name": "昌江"
                  }
              ], 
              "code": "101310206", 
              "name": "昌江"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101310207", 
                      "name": "白沙"
                  }
              ], 
              "code": "101310207", 
              "name": "白沙"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101310208", 
                      "name": "琼中"
                  }
              ], 
              "code": "101310208", 
              "name": "琼中"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101310209", 
                      "name": "定安"
                  }
              ], 
              "code": "101310209", 
              "name": "定安"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101310210", 
                      "name": "屯昌"
                  }
              ], 
              "code": "101310210", 
              "name": "屯昌"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101310211", 
                      "name": "琼海"
                  }
              ], 
              "code": "101310211", 
              "name": "琼海"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101310212", 
                      "name": "文昌"
                  }
              ], 
              "code": "101310212", 
              "name": "文昌"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101310214", 
                      "name": "保亭"
                  }
              ], 
              "code": "101310214", 
              "name": "保亭"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101310215", 
                      "name": "万宁"
                  }
              ], 
              "code": "101310215", 
              "name": "万宁"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101310216", 
                      "name": "陵水"
                  }
              ], 
              "code": "101310216", 
              "name": "陵水"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101310217", 
                      "name": "西沙"
                  }
              ], 
              "code": "101310217", 
              "name": "西沙"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101310220", 
                      "name": "南沙"
                  }
              ], 
              "code": "101310220", 
              "name": "南沙"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101310221", 
                      "name": "乐东"
                  }
              ], 
              "code": "101310221", 
              "name": "乐东"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101310222", 
                      "name": "五指山"
                  }
              ], 
              "code": "101310222", 
              "name": "五指山"
          }
      ], 
      "code": "101310101", 
      "name": "海南"
  }, 
  {
      "cities": [
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101320101", 
                      "name": "香港"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101320103", 
                      "name": "新界"
                  }
              ], 
              "code": "101320101", 
              "name": "香港"
          }
      ], 
      "code": "101320101", 
      "name": "香港"
  }, 
  {
      "cities": [
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101330101", 
                      "name": "澳门"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101330102", 
                      "name": "氹仔岛"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101330103", 
                      "name": "路环岛"
                  }
              ], 
              "code": "101330101", 
              "name": "澳门"
          }
      ], 
      "code": "101330101", 
      "name": "澳门"
  }, 
  {
      "cities": [
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101340101", 
                      "name": "台北"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101340102", 
                      "name": "桃园"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101340103", 
                      "name": "新竹"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101340104", 
                      "name": "宜兰"
                  }
              ], 
              "code": "101340101", 
              "name": "台北"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101340201", 
                      "name": "高雄"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101340202", 
                      "name": "嘉义"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101340203", 
                      "name": "台南"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101340204", 
                      "name": "台东"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101340205", 
                      "name": "屏东"
                  }
              ], 
              "code": "101340201", 
              "name": "高雄"
          }, 
          {
              "cities": [
                  {
                      "cities": [ ], 
                      "code": "101340401", 
                      "name": "台中"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101340402", 
                      "name": "苗栗"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101340403", 
                      "name": "彰化"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101340404", 
                      "name": "南投"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101340405", 
                      "name": "花莲"
                  }, 
                  {
                      "cities": [ ], 
                      "code": "101340406", 
                      "name": "云林"
                  }
              ], 
              "code": "101340401", 
              "name": "台中"
          }
      ], 
      "code": "101340101", 
      "name": "台湾"
  }
]